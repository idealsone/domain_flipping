CVTara update 3.12.1

1. In hPanel > File Manager open the folder that contains both "public_html" and "cvtara_app" (domains/cvtara.com).
2. Upload this ZIP there and choose Extract. Say yes to overwrite.
   It does not touch .env, storage, vendor or your database.
3. Sign in to the owner console > Speed & traffic > "Clear ready-made pages", then "Rebuild all pages now".
4. Hard refresh the site (Ctrl+Shift+R).

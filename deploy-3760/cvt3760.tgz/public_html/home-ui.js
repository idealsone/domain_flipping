(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const E = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // job-link copy stays hidden until the owner switches job links on
  if (document.querySelector('[data-needs-link]')) fetch('/api/public-content', { credentials: 'same-origin' }).then(r => r.json()).then(j => { if ((j.content || {}).jobLinks) document.querySelectorAll('[data-needs-link]').forEach(n => { n.hidden = false; }); }).catch(() => {});
  fetch('/api/public-content', { credentials: 'same-origin' }).then(r => r.json()).then(j => { const e = ((j.content || {}).site || {}).employers, box = $('#employerNames'); if (!e || !e.enabled || !box || !(e.names || []).length) return; $('#employerHead').textContent = e.heading || 'Employers across India'; $('#employerList').innerHTML = e.names.map(n => `<li>${E(n)}</li>`).join(''); box.hidden = false; }).catch(() => {});
  // optional rotating role at the end of the headline: only when the owner lists job titles (Owner console → Templates & site design)
  const roles = [];
  const out = $('#lpRotate');
  const rotate = () => {
    if (!out || !roles.length) return;
    out.textContent = roles[0];
    if (roles.length < 2 || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    // swap the whole word every few seconds (a soft fade, not a letter-by-letter typing loop), only while it can be seen
    let r = 0, seen = true;
    if (window.IntersectionObserver) new IntersectionObserver(es => { seen = es[0].isIntersecting; }).observe(out);
    setInterval(() => {
      if (!seen || document.hidden) return;
      out.classList.add('is-out');
      setTimeout(() => { r = (r + 1) % roles.length; out.textContent = roles[r]; out.classList.remove('is-out'); }, 260);
    }, 2600);
  };
  let site = null;
  const announceHtml = from => E((site && site.announce) || 'Create your account, build and preview · Plans from {{from}} · Pay once, no auto-renewal').replace('{{from}}', from) + ' · <a href="#pricing">' + E((site && site.announceLink) || 'See plans') + '</a>';
  const rich = t => E(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  // stats from real library + plan data
  const D = window.CVTARA_DATA;
  if (D) { const counts = () => { const t = D.templates.filter(x => x.publicPublished !== false && !x.curatedHidden).length, l = D.coverLetters.filter(x => x.publicPublished !== false).length; if ($('#stTemplates')) $('#stTemplates').textContent = t; if ($('#stLetters')) $('#stLetters').textContent = l; document.querySelectorAll('[data-st=templates]').forEach(n => { n.textContent = t; }); document.querySelectorAll('[data-st=letters]').forEach(n => { n.textContent = l; }); }; counts(); addEventListener('load', () => { counts(); setTimeout(counts, 800); }); }
  const apply = d => {
    const prices = Object.values(d.plans || {}).filter(p => p.type === 'plan' && p.price > 0).map(p => p.price);
    if (prices.length) {
      const min = Math.min(...prices), inr = n => '₹' + n.toLocaleString('en-IN');
      const jh = (d.plans || {})['job-hunt']; if (jh && jh.sale !== false) { if ($('#stHunt')) $('#stHunt').textContent = inr(jh.price); if ($('#stHuntJobs')) $('#stHuntJobs').textContent = jh.savedResumes; }
      if ($('#stFrom')) $('#stFrom').textContent = inr(min); document.querySelectorAll('[data-st=from]').forEach(n => { n.textContent = inr(min); }); if ($('#getFrom')) $('#getFrom').textContent = inr(min);
      const a = $('#lpAnnounce');
      if (a) a.innerHTML = announceHtml(inr(min));
    }
  };
  window.CVTaraPlans?.load ? window.CVTaraPlans.load().then(apply).catch(() => {}) : fetch('/api/business-public').then(r => r.json()).then(apply).catch(() => {});
  addEventListener('load', () => window.CVTaraPlans?.load().then(apply).catch(() => {}));
  // persona selection
  document.querySelectorAll('#lpPersona [data-aud]').forEach(b => b.addEventListener('click', () => {
    try { localStorage.setItem('cvtara-audience', b.dataset.aud); } catch {}
    const host = $('#homePlans');
    host?.setAudience?.(b.dataset.aud);
    $('#pricing')?.scrollIntoView({ behavior: 'smooth' });
    history.replaceState(null, '', '#pricing');
  }));
  // approved reviews only
  const box = $('#lpReviews');
  if (box) fetch('/api/public-content', { headers: { Accept: 'application/json' } }).then(r => r.json()).then(d => {
    const rev = (d.reviews || []).filter(r => r.verified).slice(0, 6);
    // the section stays hidden until there is at least one approved review, so a new site never shows an empty wall
    if (!rev.length) return;
    box.innerHTML = rev.map(r => `<article class="lp-review"><div class="stars" aria-label="${r.rating} out of 5">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div><p>“${E(r.content)}”</p><b>${E(r.display_name)}</b>${r.designation || r.company ? `<small>${E([r.designation, r.company].filter(Boolean).join(', '))}</small>` : ''}<span class="lp-verified">✓ Verified customer${r.created_at ? ' · ' + E(new Date(String(r.created_at).replace(' ', 'T')).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })) : ''}</span></article>`).join('');
    const sec = $('#reviews'); if (sec) sec.hidden = false;
  }).catch(() => { box.innerHTML = ''; });
  // owner-editable homepage copy (Owner console → Templates & site design)
  fetch('/api/public-content', { headers: { Accept: 'application/json' } }).then(r => r.json()).then(d => {
    const s = d.content && d.content.site; if (!s) return; site = s;
    if (Array.isArray(s.heroRoles) && s.heroRoles.length) { roles.push(...s.heroRoles.filter(Boolean)); rotate(); }
    const h1 = $('.lp-hero h1'); if (h1 && h1.firstChild && s.heroTitle) h1.firstChild.nodeValue = s.heroTitle + ' ';
    const pill = $('.lp-pill'); if (pill && pill.lastChild && s.heroPill) pill.lastChild.nodeValue = s.heroPill;
    if ($('.lp-lead') && s.heroLead) $('.lp-lead').innerHTML = rich(s.heroLead);
    if ($('.lp-cta .primary') && s.ctaPrimary) $('.lp-cta .primary').textContent = s.ctaPrimary;
    if ($('.lp-cta .secondary') && s.ctaSecondary) $('.lp-cta .secondary').textContent = s.ctaSecondary;
    if ($('.lp-final h2') && s.ctaFinalTitle) $('.lp-final h2').textContent = s.ctaFinalTitle;
    if ($('.lp-final p') && s.ctaFinalText) $('.lp-final p').textContent = s.ctaFinalText;
    if ($('.lp-final .button') && s.ctaFinalButton) $('.lp-final .button').textContent = s.ctaFinalButton;
    const a = $('#lpAnnounce'), from = $('#stFrom') ? $('#stFrom').textContent : '₹99'; if (a) a.innerHTML = announceHtml(from);
  }).catch(() => {});
})();
// 3.70.0 On phones the bottom "Check free / View plans" bar waits until the hero (which has its own buttons) has scrolled away,
// so the first screen has one clear button instead of three.
(() => {
  const hero = document.querySelector('.lp-hero');
  if (!hero || !('IntersectionObserver' in window)) return;
  document.documentElement.classList.add('lp-hero-in');
  new IntersectionObserver(es => document.documentElement.classList.toggle('lp-hero-in', es[0].isIntersecting), { threshold: 0.15 }).observe(hero);
})();

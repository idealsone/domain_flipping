<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Anonymous, aggregate-only funnel steps for visitors who have not signed up yet
        // (resume check run, "build my resume" clicked, package clicked). No resume text is stored.
        Schema::create('funnel_events', function (Blueprint $t) {
            $t->id();
            $t->string('visitor_hash', 64);
            $t->string('step', 30);
            $t->string('detail', 40)->default('');
            $t->date('day');
            $t->timestamps();
            $t->unique(['visitor_hash', 'step', 'detail', 'day']);
            $t->index(['step', 'day']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('funnel_events');
    }
};

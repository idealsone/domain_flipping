<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Consent-based marketing contacts. Every row records where the contact came from and
        // on what basis they agreed to hear from CVTara, so unsubscribes and audits are simple.
        Schema::create('leads', function (Blueprint $t) {
            $t->id();
            $t->string('email')->unique();
            $t->string('name', 120)->default('');
            $t->string('source', 80)->default('manual');
            $t->string('source_note', 255)->default('');
            $t->string('consent_basis', 40);
            $t->timestamp('consented_at');
            $t->string('status', 20)->default('new');
            $t->unsignedTinyInteger('campaign_step')->default(0);
            $t->timestamp('last_sent_at')->nullable();
            $t->boolean('stop_marketing')->default(false);
            $t->string('unsubscribe_token', 64)->unique();
            $t->timestamp('unsubscribed_at')->nullable();
            $t->timestamps();
            $t->index(['status', 'stop_marketing', 'campaign_step']);
        });
        // Which marketing sender delivered a message, so each sender's daily cap can be enforced.
        Schema::table('mail_outbox', function (Blueprint $t) {
            $t->string('sender_id', 60)->nullable()->index();
        });
    }

    public function down(): void
    {
        Schema::table('mail_outbox', function (Blueprint $t) {
            $t->dropIndex(['sender_id']);
            $t->dropColumn('sender_id');
        });
        Schema::dropIfExists('leads');
    }
};

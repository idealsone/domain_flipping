<?php

use App\Models\User;
use App\Services\Campaign;
use App\Services\CashfreePayouts;
use App\Services\MailAutomation;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schedule;

Artisan::command('cvtara:cron', function () {
    MailAutomation::reminders();
    CashfreePayouts::reconcile();
    $this->info(json_encode(MailAutomation::process()));
    try {
        Campaign::run();
        $this->info(json_encode(Campaign::deliver()));
    } catch (\Throwable $e) {
        report($e); // a marketing problem must never stop transactional mail or payout checks
    }
})->purpose('Process due mail and record cron health');
Schedule::command('cvtara:cron')->everyMinute()->withoutOverlapping();
Artisan::command('cvtara:admin {email} {name}', function () {
    $password = $this->secret('Owner password (12+ characters)');
    if (strlen($password) < 12) {
        $this->error('Use at least 12 characters.');

        return 1;
    } $u = User::firstOrCreate(['email' => $this->argument('email')], ['name' => $this->argument('name'), 'password' => Hash::make($password)]);
    $u->forceFill(['is_admin' => true])->save();
    $this->info('Owner account is ready.');
});

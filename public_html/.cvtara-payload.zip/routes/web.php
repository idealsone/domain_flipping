<?php
use Illuminate\Support\Facades\{Route,DB,Storage};
use Illuminate\Http\Request;
use App\Http\Controllers\{ApiController,AuthController,ContentController,ExportController,InstallController};
use App\Models\User;
Route::get('/login',fn(Request $r)=>app(AuthController::class)->page($r))->name('login');
foreach(['register','forgot-password'] as $mode){Route::get('/'.$mode.($mode==='reset-password'?'/ {token}':''),fn(Request $r)=>app(AuthController::class)->page($r,$mode));}
Route::get('/reset-password/{token}',fn(Request $r)=>app(AuthController::class)->page($r,'reset-password'));
Route::post('/login',[AuthController::class,'login'])->middleware('throttle:20,1,login');
Route::post('/register',[AuthController::class,'register'])->middleware('throttle:5,1,auth-change');
Route::post('/forgot-password',[AuthController::class,'forgot'])->middleware('throttle:3,1,password-email');
Route::post('/reset-password',[AuthController::class,'reset'])->middleware('throttle:5,1,auth-change');
Route::post('/logout',[AuthController::class,'logout']);
Route::get('/signin-with-chatgpt',fn()=>redirect('/login'));
Route::get('/r/{code}',function(Request $r,string $code){$u=User::where('referral_code',$code)->where('blocked',false)->firstOrFail();if(!$r->user()){$r->session()->put('referral',['code'=>$code,'at'=>time()]);DB::table('referral_clicks')->insertOrIgnore(['referrer_id'=>$u->id,'visitor_hash'=>hash_hmac('sha256',$r->session()->getId(),config('app.key')),'day'=>today(),'created_at'=>now(),'updated_at'=>now()]);}return redirect('/register')->header('X-Robots-Tag','noindex');})->middleware('throttle:60,1,referral');
Route::post('/webhooks/razorpay',function(Request $r){abort_if(strlen($r->getContent())>1000000,413);\App\Services\Payments::webhook($r->getContent(),$r->header('X-Razorpay-Signature',''),$r->header('X-Razorpay-Event-Id',''));return response()->json(['ok'=>true]);})->middleware('throttle:120,1,api');
Route::match(['GET','POST','DELETE'],'/api/{path?}',[ApiController::class,'run'])->where('path','.*')->middleware('throttle:120,1,api');
Route::post('/export/{type}/{id}/{format}',[ExportController::class,'download'])->middleware(['auth','throttle:10,1,exports']);
Route::get('/media/{file}',function(string $file){abort_unless(preg_match('/^[a-f0-9-]{36}\.webp$/',$file)&&Storage::disk('local')->exists('media/'.$file),404);return response(Storage::disk('local')->get('media/'.$file))->header('Content-Type','image/webp')->header('Cache-Control','public,max-age=86400');});
Route::match(['GET','POST'],'/unsubscribe/{token}',function(Request $r,string $token){
    abort_unless(preg_match('/^[A-Za-z0-9]{40}$/',$token),404);
    $page=fn(string $h,int $s=200)=>response('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Email preferences | CVTara</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#edf3fb;color:#142d49;font:18px/1.6 system-ui}main{max-width:520px;padding:32px;background:#fff;border-radius:16px;margin:16px}button{font:inherit;padding:12px 22px;border:0;border-radius:10px;background:#204dd2;color:#fff;cursor:pointer}</style></head><body><main>'.$h.'</main></body></html>',$s)->header('Cache-Control','no-store')->header('X-Robots-Tag','noindex');
    if($r->isMethod('POST')){\App\Services\Campaign::unsubscribe($token);return $page('<h1>You are unsubscribed</h1><p>You will not receive marketing emails from CVTara. Account and payment emails you need will still be sent.</p>');}
    return $page('<h1>Unsubscribe from CVTara emails?</h1><form method="post"><button type="submit">Yes, unsubscribe me</button></form>');
})->middleware('throttle:30,1,unsubscribe');
Route::get('/{path?}',[ContentController::class,'show'])->where('path','.*');

Route::post('/webhooks/cashfree',function(Request $r){abort_if(strlen($r->getContent())>1000000,413);\App\Services\CashfreeCheckout::webhook($r->getContent(),$r->header('x-webhook-timestamp',''),$r->header('x-webhook-signature',''));return response()->json(['ok'=>true]);})->middleware('throttle:120,1,api');

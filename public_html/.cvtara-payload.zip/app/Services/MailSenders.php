<?php

namespace App\Services;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

/**
 * Extra, named SMTP senders for marketing mail.
 *
 * The main "email" integration (Integrations tab) stays dedicated to transactional mail such as
 * password resets and receipts. Marketing mail is sent only through a sender listed here, each with
 * its own daily cap, so a marketing problem can never damage the transactional mailbox.
 */
class MailSenders
{
    public const MAX = 6;

    /** @return list<array<string,mixed>> */
    public static function all(): array
    {
        $raw = Settings::get('mail_senders', '');
        if (! $raw || ! is_string($raw)) {
            return [];
        }
        try {
            return json_decode(Crypt::decryptString($raw), true) ?: [];
        } catch (\Throwable) {
            return [];
        }
    }

    /** Sender list for the console: secrets are never returned. */
    public static function forDisplay(): array
    {
        return array_map(function ($s) {
            $hasPassword = ! empty($s['smtpPassword']);
            unset($s['smtpPassword']);
            $s['hasPassword'] = $hasPassword;
            $s['sentToday'] = self::sentToday($s['id']);

            return $s;
        }, self::all());
    }

    public static function find(?string $id): ?array
    {
        foreach (self::all() as $s) {
            if ($s['id'] === $id) {
                return $s;
            }
        }

        return null;
    }

    public static function save(array $incoming): array
    {
        if (count($incoming) > self::MAX) {
            throw ValidationException::withMessages(['senders' => 'You can add up to '.self::MAX.' marketing senders.']);
        }
        $existing = collect(self::all())->keyBy('id');
        $out = [];
        $seen = [];
        foreach (array_values($incoming) as $s) {
            $v = validator((array) $s, [
                'id' => ['nullable', 'regex:/^[a-z0-9-]{3,40}$/'],
                'label' => 'required|string|max:60',
                'fromEmail' => 'required|email|max:190',
                'fromName' => 'required|string|max:80',
                'smtpHost' => ['required', 'string', 'max:190', 'regex:/^[A-Za-z0-9.-]+$/'],
                'smtpPort' => 'required|integer|in:25,465,587,2525',
                'smtpUser' => 'required|string|max:190',
                'smtpPassword' => 'nullable|string|max:300',
                'dailyCap' => 'required|integer|min:1|max:2000',
                'enabled' => 'required|boolean',
            ], [], ['fromEmail' => 'sender email', 'smtpHost' => 'SMTP host'])->validate();
            $id = ($v['id'] ?? '') ?: 'sender-'.substr(bin2hex(random_bytes(4)), 0, 8);
            abort_if(isset($seen[$id]), 422, 'Duplicate sender id.');
            $seen[$id] = true;
            $password = ($v['smtpPassword'] ?? '') !== '' ? $v['smtpPassword'] : ($existing[$id]['smtpPassword'] ?? '');
            abort_if($password === '', 422, 'Enter the SMTP password for '.$v['label'].'.');
            $out[] = array_merge($v, ['id' => $id, 'smtpPassword' => $password, 'smtpPort' => (int) $v['smtpPort'], 'dailyCap' => (int) $v['dailyCap']]);
        }
        Settings::put('mail_senders', Crypt::encryptString(json_encode($out)));

        return $out;
    }

    public static function sentToday(string $id): int
    {
        return DB::table('mail_outbox')->where('sender_id', $id)->where('status', 'sent')->where('sent_at', '>=', now()->startOfDay())->count();
    }

    public static function remainingToday(array $s): int
    {
        return max(0, (int) $s['dailyCap'] - self::sentToday($s['id']));
    }

    /** Registers a dedicated mailer for this sender and returns its name (default mailer is untouched). */
    public static function mailer(array $s): string
    {
        $name = 'marketing_'.$s['id'];
        config(['mail.mailers.'.$name => [
            'transport' => 'smtp', 'host' => $s['smtpHost'], 'port' => (int) $s['smtpPort'],
            'username' => $s['smtpUser'], 'password' => $s['smtpPassword'],
            'scheme' => (int) $s['smtpPort'] === 465 ? 'smtps' : null, 'timeout' => 15,
        ]]);
        app('mail.manager')->purge($name);

        return $name;
    }

    /** @param array<string,string> $headers */
    public static function send(array $s, string $to, string $subject, string $body, array $headers = []): void
    {
        Mail::mailer(self::mailer($s))->raw($body, function ($m) use ($s, $to, $subject, $headers) {
            $m->from($s['fromEmail'], $s['fromName'])->to($to)->subject($subject);
            foreach ($headers as $k => $v) {
                $m->getSymfonyMessage()->getHeaders()->addTextHeader($k, $v);
            }
        });
    }
}

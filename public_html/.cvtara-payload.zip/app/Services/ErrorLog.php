<?php

namespace App\Services;

/**
 * Reads the Laravel application log so the owner can review server errors from the console.
 * Only the tail of the newest log file is read so a large log never exhausts memory.
 */
class ErrorLog
{
    private const TAIL_BYTES = 2_000_000;

    private const LEVELS = ['debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency'];

    /** @return list<string> */
    public static function files(): array
    {
        $files = glob(storage_path('logs/*.log')) ?: [];
        usort($files, fn ($a, $b) => filemtime($b) <=> filemtime($a));

        return $files;
    }

    public static function summary(): array
    {
        $files = self::files();

        return ['files' => count($files), 'bytes' => array_sum(array_map('filesize', $files)), 'newest' => $files ? date('c', filemtime($files[0])) : null];
    }

    /** @return array{entries: list<array>, counts: array<string,int>} */
    public static function recent(int $limit = 100, string $minLevel = 'warning'): array
    {
        $limit = max(1, min($limit, 300));
        $min = array_search($minLevel, self::LEVELS, true);
        $min = $min === false ? 3 : $min;
        $files = self::files();
        if (! $files) {
            return ['entries' => [], 'counts' => []];
        }
        $text = self::tail($files[0]);
        $parts = preg_split('/^\[(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:\d{2})?)\] (\w+)\.(\w+): /m', $text, -1, PREG_SPLIT_DELIM_CAPTURE) ?: [];
        $entries = [];
        $counts = [];
        for ($i = 1; $i + 3 < count($parts) + 1; $i += 4) {
            if (! isset($parts[$i + 3])) {
                break;
            }
            $level = strtolower($parts[$i + 2]);
            $lines = preg_split('/\R/', trim($parts[$i + 3]), 2);
            $counts[$level] = ($counts[$level] ?? 0) + 1;
            $rank = array_search($level, self::LEVELS, true);
            if ($rank === false || $rank < $min) {
                continue;
            }
            $entries[] = ['time' => $parts[$i], 'level' => $level, 'message' => self::redact(mb_substr($lines[0], 0, 400)), 'detail' => self::redact(mb_substr($lines[1] ?? '', 0, 2500))];
        }

        return ['entries' => array_slice(array_reverse($entries), 0, $limit), 'counts' => $counts];
    }

    /** Empties every log file (files are kept so Laravel can keep writing). */
    public static function clear(): int
    {
        $n = 0;
        foreach (self::files() as $f) {
            if (is_writable($f) && file_put_contents($f, '') !== false) {
                $n++;
            }
        }

        return $n;
    }

    public static function redact(string $s): string
    {
        $s = preg_replace('/((?:password|passwd|secret|token|api[_-]?key|authorization|signature)["\']?\s*[:=]\s*["\']?)[^\s"\',;)]+/i', '$1[hidden]', $s) ?? $s;

        return preg_replace('/\b[A-Za-z0-9_\-]{40,}\b/', '[hidden]', $s) ?? $s;
    }

    private static function tail(string $file): string
    {
        $size = filesize($file);
        $h = fopen($file, 'rb');
        if (! $h) {
            return '';
        }
        if ($size > self::TAIL_BYTES) {
            fseek($h, -self::TAIL_BYTES, SEEK_END);
            fgets($h); // drop the partial first line
        }
        $text = stream_get_contents($h) ?: '';
        fclose($h);

        return $text;
    }
}

<?php

namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BusinessControls
{
    public static function get(): array
    {
        $value = array_replace_recursive(['maintenance' => ['enabled' => false, 'allowIps' => [], 'title' => 'We’re making CVTara better.', 'message' => 'Scheduled maintenance is in progress. Your saved work is safe. Please check back soon.'], 'brand' => ['about' => 'Built by an HR professional working in the edtech industry, helping job seekers prepare clear resumes and more focused applications.'], 'growth' => Referrals::config(), 'coupons' => []], Settings::get('business_controls', []));
        $value['growth'] = Referrals::config();

        return $value;
    }

    public static function save(Request $r): array
    {
        $v = $r->validate(['maintenance.enabled' => 'required|boolean', 'maintenance.title' => 'required|string|max:120', 'maintenance.message' => 'required|string|max:800', 'maintenance.allowIps' => 'nullable|array|max:20', 'maintenance.allowIps.*' => ['string', 'max:64', fn ($a, $v, $fail) => self::validIpRule($v) ?: $fail('Enter valid IP addresses or ranges such as 203.0.113.7 or 203.0.113.0/24.')], 'brand.about' => 'required|string|min:20|max:600', 'growth.enabled' => 'required|boolean', 'growth.rateBps' => 'required|integer|min:0|max:5000', 'growth.tierRateBps' => 'required|integer|min:0|max:5000', 'growth.tierThreshold' => 'required|integer|min:1|max:100000', 'growth.minimumPaise' => 'required|integer|min:100|max:100000000', 'growth.holdDays' => 'required|integer|min:1|max:60', 'growth.downloadThreshold' => 'required|integer|min:1|max:10000', 'growth.premiumThreshold' => 'required|integer|min:2|max:10000|gt:growth.downloadThreshold', 'growth.premiumDays' => 'required|integer|min:1|max:365', 'coupons' => 'present|array|max:100', 'coupons.*.code' => 'required|distinct|regex:/^[A-Z0-9_-]{3,30}$/', 'coupons.*.type' => 'required|in:percent,fixed', 'coupons.*.value' => 'required|integer|min:1|max:99999', 'coupons.*.enabled' => 'required|boolean', 'coupons.*.plans' => 'required|array|min:1', 'coupons.*.plans.*' => 'required|in:single,monthly,annual', 'coupons.*.expiresAt' => 'nullable|date_format:Y-m-d']);
        foreach ($v['coupons'] as &$c) {
            abort_if($c['type'] === 'percent' && $c['value'] > 90, 422, 'Percentage discounts cannot exceed 90%.');
            $c['expiresAt'] = $c['expiresAt'] ?? '';
        }unset($c);
        // Callers that do not send the allow-list (the Business controls form) must not erase it.
        $v['maintenance']['allowIps'] = array_key_exists('allowIps', $v['maintenance']) && $v['maintenance']['allowIps'] !== null ? array_values($v['maintenance']['allowIps']) : (self::get()['maintenance']['allowIps'] ?? []);
        DB::transaction(function () use ($v, $r) {
            Settings::put('business_controls', $v);
            Settings::put('referrals', array_merge(Referrals::config(), $v['growth']));
            Settings::audit($r->user()->id, 'business_controls_saved');
        });

        return $v;
    }

    public static function validIpRule(string $v): bool
    {
        [$ip, $mask] = array_pad(explode('/', trim($v), 2), 2, null);
        if (! filter_var($ip, FILTER_VALIDATE_IP)) {
            return false;
        }

        return $mask === null || (ctype_digit($mask) && (int) $mask <= (str_contains($ip, ':') ? 128 : 32));
    }

    /** Owner switch used by the System tab. Keeps every other business control unchanged. */
    public static function setMaintenance(Request $r, bool $enabled, ?array $allowIps = null, ?string $title = null, ?string $message = null): array
    {
        $cur = self::get();
        $m = $cur['maintenance'];
        $m['enabled'] = $enabled;
        if ($allowIps !== null) {
            $m['allowIps'] = array_values(array_unique(array_map('trim', $allowIps)));
        }
        if ($title !== null && $title !== '') {
            $m['title'] = mb_substr($title, 0, 120);
        }
        if ($message !== null && $message !== '') {
            $m['message'] = mb_substr($message, 0, 800);
        }
        $stored = Settings::get('business_controls', []);
        $stored['maintenance'] = $m;
        Settings::put('business_controls', $stored);
        Settings::audit($r->user()->id, $enabled ? 'maintenance_on' : 'maintenance_off');

        return $m;
    }

    public static function quote(string $plan, string $code = ''): array
    {
        $p = Settings::plans()[$plan] ?? null;
        abort_unless($p && $plan !== 'free', 422, 'Choose a paid plan.');
        $subtotal = (int) round($p['price'] * 100);
        $discount = 0;
        $code = strtoupper(trim($code));
        if ($code) {
            $c = collect(self::get()['coupons'])->first(fn ($c) => $c['code'] === $code && $c['enabled'] && in_array($plan, $c['plans']) && (! $c['expiresAt'] || $c['expiresAt'] >= now('UTC')->toDateString()));
            abort_unless($c, 422, 'This coupon is invalid, expired or unavailable for this plan.');
            $discount = min($subtotal - 100, $c['type'] === 'percent' ? intdiv($subtotal * $c['value'], 100) : $c['value'] * 100);
            abort_if($discount < 0, 422);
        }

        return ['plan' => $plan, 'code' => $code, 'subtotalPaise' => $subtotal, 'discountPaise' => $discount, 'totalPaise' => $subtotal - $discount, 'accessDays' => $p['accessDays'], 'bonusDays' => $p['bonusDays'] ?? 0];
    }
}

<?php

namespace App\Services;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class Settings
{
    public static function defaults(): array
    {
        return json_decode(file_get_contents(resource_path('data/defaults.json')), true);
    }

    public static function get(string $key, $fallback = null)
    {
        $r = DB::table('site_settings')->where('key', $key)->first();
        $value = $r ? json_decode($r->value_json, true) : (self::defaults()[$key] ?? $fallback);
        if ($key === 'blog') {
            foreach (json_decode(file_get_contents(resource_path('data/editorial-content.json')), true) as $slug => $post) {
                if (empty($value[$slug]['body'])) {
                    $value[$slug] = array_merge($post, $value[$slug] ?? [], ['body' => $post['body']]);
                }
            }
        }

return $value;
    }

    public static function revision(string $key): int
    {
        return (int) (DB::table('site_settings')->where('key', $key)->value('revision') ?? 0);
    }

    public static function put(string $key, $data): void
    {
        DB::table('site_settings')->updateOrInsert(['key' => $key], ['value_json' => json_encode($data), 'revision' => self::revision($key) + 1, 'updated_at' => now(), 'created_at' => now()]);
    }

    public static function providers(): array
    {
        $p = self::get('providers', '');

        return $p ? json_decode(Crypt::decryptString($p), true) : [];
    }

    public static function plans(): array
    {
        $defaults = ['free' => ['name' => 'Free', 'price' => 0, 'savedResumes' => 2, 'dailyMatches' => 3, 'accessDays' => 0, 'exports' => 0], 'single' => ['name' => 'Single resume', 'price' => 99, 'savedResumes' => 1, 'dailyMatches' => 5, 'accessDays' => 30, 'exports' => 1], 'monthly' => ['name' => 'Monthly', 'price' => 199, 'savedResumes' => 3, 'dailyMatches' => 10, 'accessDays' => 30, 'exports' => 6], 'annual' => ['name' => 'Annual', 'price' => 1990, 'savedResumes' => 12, 'dailyMatches' => 20, 'accessDays' => 365, 'bonusDays' => 65, 'exports' => 72]];

        return array_replace_recursive($defaults, self::get('plans', []));
    }

    public static function access(int $user): array
    {
        $p = DB::table('purchases')->where('owner_id', $user)->where('status', 'paid')->where('access_until', '>', now())->orderByDesc('purchased_at')->first();
        $plan = $p ? $p->plan : 'free';
        $limits = $p ? json_decode($p->limits_json, true) : self::plans()['free'];

        return ['plan' => $plan, 'paid' => (bool) $p, 'limits' => $limits, 'accessUntil' => $p?->access_until, 'purchase' => $p];
    }

    public static function audit($user, string $event, string $ref = ''): void
    {
        DB::table('activity_events')->insert(['id' => (string) Str::uuid(), 'owner_id' => $user, 'event' => $event, 'reference' => substr($ref, 0, 255), 'created_at' => now(), 'updated_at' => now()]);
    }
}

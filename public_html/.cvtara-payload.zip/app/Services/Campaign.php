<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Consent-based follow-up emails for marketing contacts ("leads").
 *
 * - A contact is only added with a recorded source and consent basis.
 * - Each email carries the owner's postal address and a working unsubscribe link.
 * - Sending stops automatically after an unsubscribe or after the contact buys a plan.
 * - Messages go only through a marketing sender (see MailSenders) and respect its daily cap.
 */
class Campaign
{
    public const BASES = ['signup_form' => 'Signed up on a CVTara form', 'customer_opt_in' => 'Existing customer who opted in', 'event_or_referral' => 'Gave permission in person / by referral', 'written_consent' => 'Gave written permission by email'];

    public const SOURCES = ['website', 'workspace', 'webinar', 'partner', 'linkedin_inbound', 'manual', 'import'];

    public const MAX_STEPS = 12;

    public static function defaults(): array
    {
        return [
            'enabled' => false,
            'senderId' => '',
            'dailyLimit' => 50,
            'steps' => [
                ['day' => 1, 'subject' => 'Welcome to CVTara, {{name}}', 'body' => "Hi {{name}},\n\nThanks for your interest in CVTara. You can build a resume, write a matching cover letter and compare your resume with a job description. A draft is always free to save.\n\nStart here: {{site_url}}\n\nIf you have a question, just reply to this email."],
                ['day' => 7, 'subject' => 'A quick way to check your resume against a job', 'body' => "Hi {{name}},\n\nBefore your next application, paste the job description into Resume Match. It shows which requirements your resume already supports and which are missing, so you can edit truthfully.\n\nTry it: {{site_url}}\n"],
                ['day' => 21, 'subject' => 'Keep your applications organised', 'body' => "Hi {{name}},\n\nThe application tracker keeps every role, follow-up date and resume version in one place.\n\nOpen CVTara: {{site_url}}\n"],
                ['day' => 45, 'subject' => 'Still job hunting?', 'body' => "Hi {{name}},\n\nIf you are still applying, CVTara has templates for freshers and experienced professionals plus matching cover letters.\n\nSee what is new: {{site_url}}\n"],
                ['day' => 90, 'subject' => 'Last note from CVTara', 'body' => "Hi {{name}},\n\nThis is our last scheduled email. You can return to CVTara any time at {{site_url}}.\n\nWishing you a good search."],
            ],
        ];
    }

    public static function config(): array
    {
        $c = array_replace(self::defaults(), (array) Settings::get('campaign', []));
        if (empty($c['steps']) || ! is_array($c['steps'])) {
            $c['steps'] = self::defaults()['steps'];
        }

        return $c;
    }

    public static function saveConfig(array $in): array
    {
        $v = validator($in, [
            'enabled' => 'required|boolean',
            'senderId' => 'nullable|string|max:60',
            'dailyLimit' => 'required|integer|min:1|max:2000',
            'steps' => 'required|array|min:1|max:'.self::MAX_STEPS,
            'steps.*.day' => 'required|integer|min:1|max:365',
            'steps.*.subject' => 'required|string|max:150',
            'steps.*.body' => 'required|string|max:5000',
        ])->validate();
        $steps = collect($v['steps'])->sortBy('day')->values()->all();
        abort_if(count(array_unique(array_column($steps, 'day'))) !== count($steps), 422, 'Each email must be sent on a different day.');
        abort_if($v['enabled'] && ! MailSenders::find($v['senderId'] ?? ''), 422, 'Choose a saved marketing sender before turning the campaign on.');
        $v['steps'] = $steps;
        $v['senderId'] = $v['senderId'] ?? '';
        Settings::put('campaign', $v);

        return $v;
    }

    /** @return 'added'|'exists'|'blocked'|'invalid' */
    public static function addLead(string $email, string $name, string $source, string $note, string $basis): string
    {
        $email = strtolower(trim($email));
        if (! filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190 || ! isset(self::BASES[$basis])) {
            return 'invalid';
        }
        if ($lead = DB::table('leads')->where('email', $email)->first()) {
            // Someone who unsubscribed is never silently re-added.
            return $lead->stop_marketing ? 'blocked' : 'exists';
        }
        DB::table('leads')->insert([
            'email' => $email, 'name' => mb_substr(trim($name), 0, 120), 'source' => in_array($source, self::SOURCES, true) ? $source : 'manual',
            'source_note' => mb_substr(trim($note), 0, 255), 'consent_basis' => $basis, 'consented_at' => now(), 'status' => 'new', 'campaign_step' => 0,
            'unsubscribe_token' => Str::random(40), 'created_at' => now(), 'updated_at' => now(),
        ]);

        return 'added';
    }

    /** @return array{added:int,exists:int,blocked:int,invalid:int} */
    public static function importCsv(string $csv, string $source, string $note, string $basis): array
    {
        $out = ['added' => 0, 'exists' => 0, 'blocked' => 0, 'invalid' => 0];
        $rows = preg_split('/\R/', trim($csv)) ?: [];
        abort_if(count($rows) > 5001, 422, 'Import up to 5,000 contacts at a time.');
        foreach ($rows as $i => $line) {
            $cols = str_getcsv($line);
            $email = trim((string) ($cols[0] ?? ''));
            if ($i === 0 && ! str_contains($email, '@')) {
                continue; // header row
            }
            if ($email === '') {
                continue;
            }
            $out[self::addLead($email, (string) ($cols[1] ?? ''), $source, $note, $basis)]++;
        }

        return $out;
    }

    public static function unsubscribe(string $token): bool
    {
        $lead = DB::table('leads')->where('unsubscribe_token', $token)->first();
        if (! $lead) {
            return false;
        }
        DB::table('leads')->where('id', $lead->id)->update(['stop_marketing' => true, 'status' => 'unsubscribed', 'unsubscribed_at' => $lead->unsubscribed_at ?? now(), 'updated_at' => now()]);
        DB::table('mail_outbox')->where('trigger', 'campaign')->where('recipient', $lead->email)->whereIn('status', ['queued', 'failed'])->update(['status' => 'cancelled']);
        $userIds = DB::table('users')->whereRaw('lower(email) = ?', [$lead->email])->pluck('id');
        if ($userIds->isNotEmpty()) {
            DB::table('profiles')->whereIn('owner_id', $userIds)->update(['marketing_consent' => false]);
        }

        return true;
    }

    /** Queues the next due email for each eligible lead. */
    public static function run(): array
    {
        $c = self::config();
        if (! $c['enabled']) {
            return ['queued' => 0, 'paused' => 'Campaign is off.'];
        }
        $sender = MailSenders::find($c['senderId']);
        if (! $sender || ! $sender['enabled']) {
            return ['queued' => 0, 'paused' => 'Choose an enabled marketing sender.'];
        }
        $address = trim((string) (Settings::get('legal')['address'] ?? ''));
        if ($address === '') {
            return ['queued' => 0, 'paused' => 'Add your postal address under Footer & policies. It is required in every marketing email.'];
        }
        self::markConverted();
        $committed = DB::table('mail_outbox')->where('trigger', 'campaign')->where('created_at', '>=', now()->startOfDay())->where('status', '!=', 'cancelled')->count();
        $budget = min((int) $c['dailyLimit'], (int) $sender['dailyCap']) - $committed;
        $queued = 0;
        $steps = $c['steps'];
        foreach (DB::table('leads')->whereIn('status', ['new', 'nurturing'])->where('stop_marketing', false)->where('campaign_step', '<', count($steps))->orderBy('id')->limit(500)->get() as $lead) {
            if ($queued >= $budget) {
                break;
            }
            $step = $steps[$lead->campaign_step];
            $dueAt = \Illuminate\Support\Carbon::parse($lead->consented_at)->addDays((int) $step['day']);
            // Never send two emails less than three days apart, even when catching up on old contacts.
            if ($dueAt->isFuture() || ($lead->last_sent_at && \Illuminate\Support\Carbon::parse($lead->last_sent_at)->addDays(3)->isFuture())) {
                continue;
            }
            $url = url('/unsubscribe/'.$lead->unsubscribe_token);
            $vars = ['name' => $lead->name !== '' ? $lead->name : 'there', 'site_url' => config('app.url'), 'unsubscribe_url' => $url];
            $fill = fn (string $s) => preg_replace_callback('/\{\{([a-z_]+)\}\}/', fn ($m) => (string) ($vars[$m[1]] ?? ''), $s);
            $body = $fill($step['body'])."\n\n--\nYou are receiving this because you asked to hear from CVTara (".(self::BASES[$lead->consent_basis] ?? 'opt-in').").\nUnsubscribe: ".$url."\nCVTara, ".$address;
            $inserted = DB::table('mail_outbox')->insertOrIgnore(['id' => (string) Str::uuid(), 'dedupe' => hash('sha256', 'campaign:'.$lead->id.':'.$lead->campaign_step), 'owner_id' => null, 'trigger' => 'campaign', 'recipient' => $lead->email, 'subject' => $fill($step['subject']), 'body' => $body, 'sender_id' => $sender['id'], 'due_at' => now(), 'created_at' => now(), 'updated_at' => now()]);
            DB::table('leads')->where('id', $lead->id)->update(['campaign_step' => $lead->campaign_step + 1, 'status' => 'nurturing', 'last_sent_at' => now(), 'updated_at' => now()]);
            $queued += $inserted;
        }

        return ['queued' => $queued];
    }

    /** Sends queued campaign mail through the marketing sender. */
    public static function deliver(int $limit = 20): array
    {
        $sent = 0;
        $jobs = DB::table('mail_outbox')->where('trigger', 'campaign')->whereIn('status', ['queued', 'failed'])->where('attempts', '<', 3)->where('due_at', '<=', now())->orderBy('due_at')->limit($limit)->get();
        foreach ($jobs as $j) {
            $lead = DB::table('leads')->where('email', $j->recipient)->first();
            $sender = MailSenders::find($j->sender_id);
            if (! $lead || $lead->stop_marketing || ! $sender || ! $sender['enabled']) {
                DB::table('mail_outbox')->where('id', $j->id)->update(['status' => 'cancelled', 'updated_at' => now()]);

                continue;
            }
            if (MailSenders::remainingToday($sender) <= 0) {
                continue; // stays queued; tomorrow's allowance sends it
            }
            DB::table('mail_outbox')->where('id', $j->id)->update(['status' => 'sending', 'attempts' => $j->attempts + 1, 'updated_at' => now()]);
            try {
                $url = url('/unsubscribe/'.$lead->unsubscribe_token);
                MailSenders::send($sender, $j->recipient, $j->subject, $j->body, ['List-Unsubscribe' => '<'.$url.'>', 'List-Unsubscribe-Post' => 'List-Unsubscribe=One-Click']);
                DB::table('mail_outbox')->where('id', $j->id)->update(['status' => 'sent', 'sent_at' => now(), 'error' => '', 'updated_at' => now()]);
                $sent++;
            } catch (\Throwable $e) {
                DB::table('mail_outbox')->where('id', $j->id)->update(['status' => 'failed', 'due_at' => now()->addMinutes(30 * ($j->attempts + 1)), 'error' => 'Delivery failed. Check the marketing sender details.', 'updated_at' => now()]);
                report($e);
            }
        }

        return ['sent' => $sent];
    }

    /** Contacts who now hold a paid plan no longer receive marketing follow-ups. */
    public static function markConverted(): void
    {
        $paid = DB::table('users')->join('purchases', 'purchases.owner_id', '=', 'users.id')->where('purchases.status', 'paid')->selectRaw('lower(users.email) as e');
        DB::table('leads')->whereIn('status', ['new', 'nurturing'])->whereIn('email', $paid)->update(['status' => 'converted', 'stop_marketing' => true, 'updated_at' => now()]);
    }

    public static function summary(): array
    {
        $by = DB::table('leads')->selectRaw('status, count(*) as n')->groupBy('status')->pluck('n', 'status')->all();

        return ['total' => array_sum($by), 'byStatus' => $by, 'sentToday' => DB::table('mail_outbox')->where('trigger', 'campaign')->where('status', 'sent')->where('sent_at', '>=', now()->startOfDay())->count()];
    }
}

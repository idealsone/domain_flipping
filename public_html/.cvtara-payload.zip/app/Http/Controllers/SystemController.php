<?php

namespace App\Http\Controllers;

use App\Services\BusinessControls;
use App\Services\Campaign;
use App\Services\ErrorLog;
use App\Services\MailSenders;
use App\Services\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Owner-only "System & growth" tools: maintenance switch, error log, marketing senders, leads and campaign. */
class SystemController extends Controller
{
    public function run(Request $r, string $path)
    {
        $ok = fn ($x = []) => response()->json(['ok' => true, ...$x]);
        $get = $r->isMethod('GET');

        switch ($path) {
            case 'status':
                abort_unless($get, 405);

                return $ok([
                    'maintenance' => BusinessControls::get()['maintenance'],
                    'yourIp' => $r->ip(),
                    'log' => ErrorLog::summary(),
                    'senders' => MailSenders::forDisplay(),
                    'campaign' => Campaign::summary() + ['config' => Campaign::config()],
                    'cron' => Settings::get('cronHeartbeat'),
                    'addressSet' => trim((string) (Settings::get('legal')['address'] ?? '')) !== '',
                ]);

            case 'funnel':
                abort_unless($get, 405);
                $days = max(1, min(365, (int) $r->query('days', 30)));
                $since = now()->subDays($days);
                $steps = fn (string $s) => DB::table('funnel_events')->where('step', $s)->where('day', '>=', $since->toDateString())->distinct()->count('visitor_hash');
                $paid = DB::table('purchases')->where('status', 'paid')->where('purchased_at', '>=', $since);
                $byPlan = (clone $paid)->selectRaw('plan, is_live, count(*) as n, sum(amount_paise) as paise')->groupBy('plan', 'is_live')->get();

                return $ok([
                    'days' => $days,
                    'funnel' => [
                        'visitors' => DB::table('page_views')->where('created_at', '>=', $since)->distinct()->count('visitor_id'),
                        'atsChecks' => $steps('ats_check'),
                        'buildClicks' => $steps('build_click'),
                        'signups' => DB::table('users')->where('created_at', '>=', $since)->where('is_admin', false)->count(),
                        'resumesSaved' => DB::table('resume_drafts')->where('created_at', '>=', $since)->distinct()->count('owner_id'),
                        'tailored' => $steps('tailor_used'),
                        'checkoutStarted' => DB::table('purchases')->where('created_at', '>=', $since)->distinct()->count('owner_id'),
                        'paid' => (clone $paid)->where('is_live', true)->distinct()->count('owner_id'),
                    ],
                    'revenue' => ['livePaise' => (int) $byPlan->where('is_live', 1)->sum('paise'), 'testPurchases' => (int) $byPlan->where('is_live', 0)->sum('n')],
                    'byPlan' => $byPlan->where('is_live', 1)->values()->map(fn ($x) => ['plan' => $x->plan, 'count' => (int) $x->n, 'paise' => (int) $x->paise]),
                    'planClicks' => DB::table('funnel_events')->where('step', 'plan_click')->where('day', '>=', $since->toDateString())->selectRaw('detail, count(distinct visitor_hash) as n')->groupBy('detail')->get(),
                    'plans' => collect(Settings::plans())->map(fn ($p, $k) => ['id' => $k] + $p)->values(),
                ]);

            case 'maintenance':
                abort_if($get, 405);
                $v = $r->validate(['enabled' => 'required|boolean', 'allowIps' => 'nullable|array|max:20', 'allowIps.*' => ['string', 'max:64', fn ($a, $x, $fail) => BusinessControls::validIpRule($x) ?: $fail('Enter valid IP addresses or ranges such as 203.0.113.7 or 203.0.113.0/24.')], 'title' => 'nullable|string|max:120', 'message' => 'nullable|string|max:800']);

                return $ok(['maintenance' => BusinessControls::setMaintenance($r, (bool) $v['enabled'], $v['allowIps'] ?? null, $v['title'] ?? null, $v['message'] ?? null)]);

            case 'errors':
                abort_unless($get, 405);
                $level = in_array($r->query('level'), ['debug', 'info', 'warning', 'error', 'critical'], true) ? $r->query('level') : 'warning';

                return $ok(ErrorLog::recent((int) $r->query('limit', 100), $level) + ['summary' => ErrorLog::summary()]);

            case 'errors/clear':
                abort_if($get, 405);
                $n = ErrorLog::clear();
                Settings::audit($r->user()->id, 'error_log_cleared');

                return $ok(['cleared' => $n]);

            case 'senders':
                if ($get) {
                    return $ok(['senders' => MailSenders::forDisplay()]);
                }
                $v = $r->validate(['senders' => 'present|array|max:'.MailSenders::MAX]);
                MailSenders::save($v['senders']);
                Settings::audit($r->user()->id, 'marketing_senders_saved');

                return $ok(['senders' => MailSenders::forDisplay()]);

            case 'senders/test':
                abort_if($get, 405);
                $v = $r->validate(['id' => 'required|string|max:60', 'to' => 'required|email|max:190']);
                $s = MailSenders::find($v['id']);
                abort_unless($s, 404);
                try {
                    MailSenders::send($s, $v['to'], 'CVTara sender test', "This is a test message from your CVTara marketing sender \"{$s['label']}\". If you can read it, the SMTP details work.");
                } catch (\Throwable $e) {
                    report($e);
                    abort(422, 'The test email could not be sent. Check the SMTP host, port, username and password.');
                }

                return $ok(['sent' => true]);

            case 'campaign':
                if ($get) {
                    return $ok(['config' => Campaign::config(), 'summary' => Campaign::summary()]);
                }

                return $ok(['config' => Campaign::saveConfig($r->all())]);

            case 'leads':
                abort_unless($get, 405);
                $q = DB::table('leads')->orderByDesc('id');
                if (in_array($r->query('status'), ['new', 'nurturing', 'converted', 'unsubscribed'], true)) {
                    $q->where('status', $r->query('status'));
                }
                if ($s = trim((string) $r->query('q', ''))) {
                    $q->where(fn ($w) => $w->where('email', 'like', '%'.addcslashes($s, '%_\\').'%')->orWhere('name', 'like', '%'.addcslashes($s, '%_\\').'%'));
                }

                return $ok(['leads' => $q->limit(300)->get(['id', 'email', 'name', 'source', 'source_note', 'consent_basis', 'consented_at', 'status', 'campaign_step', 'last_sent_at', 'stop_marketing']), 'summary' => Campaign::summary(), 'bases' => Campaign::BASES, 'sources' => Campaign::SOURCES]);

            case 'leads/add':
                abort_if($get, 405);
                $v = $r->validate(['email' => 'required|email|max:190', 'name' => 'nullable|string|max:120', 'source' => 'required|in:'.implode(',', Campaign::SOURCES), 'note' => 'nullable|string|max:255', 'basis' => 'required|in:'.implode(',', array_keys(Campaign::BASES)), 'confirm' => 'accepted'], ['confirm.accepted' => 'Please confirm that this person agreed to receive your emails.']);
                $res = Campaign::addLead($v['email'], $v['name'] ?? '', $v['source'], $v['note'] ?? '', $v['basis']);
                abort_if($res === 'blocked', 422, 'This person unsubscribed earlier and cannot be added again.');
                abort_if($res === 'invalid', 422, 'Enter a valid email address.');
                Settings::audit($r->user()->id, 'lead_added', $v['source']);

                return $ok(['result' => $res]);

            case 'leads/import':
                abort_if($get, 405);
                $v = $r->validate(['csv' => 'required|string|max:600000', 'source' => 'required|in:'.implode(',', Campaign::SOURCES), 'note' => 'required|string|max:255', 'basis' => 'required|in:'.implode(',', array_keys(Campaign::BASES)), 'confirm' => 'accepted'], ['confirm.accepted' => 'Please confirm that this person agreed to receive your emails.']);
                $res = Campaign::importCsv($v['csv'], $v['source'], $v['note'], $v['basis']);
                Settings::audit($r->user()->id, 'leads_imported', $v['source'].':'.$res['added']);

                return $ok(['result' => $res]);

            case 'leads/stop':
                abort_if($get, 405);
                $v = $r->validate(['id' => 'required|integer']);
                DB::table('leads')->where('id', $v['id'])->update(['stop_marketing' => true, 'status' => DB::raw("CASE WHEN status='converted' THEN status ELSE 'unsubscribed' END"), 'updated_at' => now()]);
                DB::table('mail_outbox')->where('trigger', 'campaign')->whereIn('recipient', DB::table('leads')->where('id', $v['id'])->select('email'))->whereIn('status', ['queued', 'failed'])->update(['status' => 'cancelled']);

                return $ok();

            case 'leads/delete':
                abort_if($get, 405);
                $v = $r->validate(['id' => 'required|integer']);
                // Deleting a contact who unsubscribed would let them be re-added, so keep those on the suppression list.
                $lead = DB::table('leads')->where('id', $v['id'])->first();
                abort_if($lead && $lead->stop_marketing, 422, 'Unsubscribed contacts are kept so they are never emailed again.');
                DB::table('leads')->where('id', $v['id'])->delete();

                return $ok();
        }
        abort(404);
    }
}

CVTara update 3.14.2. Extract over the site folder, then clear and rebuild pages in Speed & traffic.

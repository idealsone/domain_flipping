<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\AccountSecurity;
use App\Services\AffiliateProfiles;
use App\Services\BusinessControls;
use App\Services\Credits;
use App\Services\JobPage;
use App\Services\MailAutomation;
use App\Services\Payments;
use App\Services\ReferralRewards;
use App\Services\Referrals;
use App\Services\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class ApiController extends Controller
{
    public function run(Request $r, string $path = '')
    {
        $u = $r->user();
        $id = $u?->id;
        $get = $r->isMethod('GET');
        if ($get && preg_match('#^(checkout/|interviews/start$|ats/scan$|traffic$|security/(send|verify)-code|referrals/(withdraw|creator|payout-profile)$|account/delete$|feedback/[^/]+/withdraw$)#', $path)) {
            abort(405);
        }if ($r->isMethod('DELETE') && ! preg_match('#^(resumes|letters|applications)/[a-f0-9-]{36}$#', $path)) {
            abort(405);
        }$d = $r->all();
        $ok = fn ($a = []) => response()->json(['ok' => true, ...$a]);
        // Per-account (or per-IP) cap for endpoints that cost a gateway call, a heavy parse or a database write, so one
        // account or script cannot flood them. Answers 429 with a plain message.
        $cap = function (string $name, int $max, int $seconds, string $msg) use ($r, $id) {
            $k = $name.':'.($id ?: 'ip:'.$r->ip());
            abort_if(\Illuminate\Support\Facades\RateLimiter::tooManyAttempts($k, $max), 429, $msg);
            \Illuminate\Support\Facades\RateLimiter::hit($k, $seconds);
        };
        if ($path === 'csrf' && $get) {
            return $ok(['token' => csrf_token()]);
        }
        if ($path === 'health') {
            return $ok(['storage' => DB::connection()->getPdo() ? 'available' : 'unavailable']);
        }
        if ($path === 'business-public' && $get) {
            $d = BusinessControls::get();

            $plans = \App\Services\Interviews::withPerks(Settings::plans());
            // A CVTara team add-on this customer has already ordered the most times allowed today is hidden until tomorrow.
            foreach ($id ? \App\Services\Services::hiddenToday($id) : [] as $k) {
                $plans[$k]['limitReached'] = true;
            }

            return $ok(['brand' => $d['brand'], 'growth' => $d['growth'], 'plans' => $plans, 'gateways' => array_column(\App\Services\Payments::publicGateways(), 'id')]);
        }
        if ($path === 'public-config') {
            return $ok(['settings' => array_merge(['heroTitle' => 'Your next resume starts with your real experience.', 'heroDescription' => 'Choose a design. Tell your story. Prepare a focused application.', 'primaryCTA' => 'Build my resume', 'secondaryCTA' => 'Check my resume', 'accent' => '#1557d2'], array_diff_key(Settings::get('public', []), array_flip(['pushEnabled', 'oneSignalAppId', 'pushDelay', 'pushMessage'])))]);
        }
        if ($path === 'promo' && $get) {
            $offer = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string) $r->query('offer', '')));
            $promo = \Illuminate\Support\Facades\Cache::remember(\App\Services\Promos::cacheKey($offer), 30, fn () => \App\Services\Promos::active($offer ?: null));

            return $ok(['promo' => $promo, 'serverTime' => gmdate('c')]);
        }
        if ($path === 'promo/event' && $r->isMethod('POST')) {
            $v = $r->validate(['id' => 'required|string|max:40', 'kind' => 'required|in:shown,click,copy,close']);
            \App\Services\Promos::track($v['id'], $v['kind']);

            return $ok();
        }
        if ($path === 'public-activity') {
            $cfg = array_merge(['enabled' => true, 'delaySeconds' => 90, 'showSeconds' => 8, 'gapSeconds' => 25, 'useLiveActivity' => true, 'showPurchases' => true, 'custom' => []], (array) Settings::get('popup', []));
            $messages = \Illuminate\Support\Facades\Cache::remember('public-activity', 60, function () use ($cfg) {
                $out = [];
                foreach ($cfg['custom'] as $m) {
                    if (! empty($m['enabled']) && ! empty($m['text'])) {
                        $out[] = ['icon' => $m['icon'] ?? '✨', 'title' => $m['title'] ?? 'CVTara', 'text' => $m['text']];
                    }
                }
                // Real buyers who chose to be named (first name and city only). Nothing here is made up.
                if ($cfg['showPurchases']) {
                    $plans = Settings::plans();
                    foreach (DB::table('purchases')->join('profiles', 'profiles.owner_id', '=', 'purchases.owner_id')->where('purchases.status', 'paid')->where('purchases.amount_paise', '>', 0)->where('purchases.provider', '!=', 'referral_reward')->where('profiles.show_in_activity', true)->where('purchases.created_at', '>=', now()->subDays(14))->orderByDesc('purchases.created_at')->limit(8)->get(['purchases.plan', 'purchases.created_at as at', 'profiles.name', 'profiles.city']) as $p) {
                        $first = Str::of($p->name)->trim()->before(' ')->limit(20, '')->toString();
                        if ($first === '' || empty($plans[$p->plan])) {
                            continue;
                        }
                        $out[] = ['kind' => 'purchase', 'icon' => '🛍️', 'name' => Str::title(mb_strtolower($first)), 'city' => Str::title(mb_strtolower(trim((string) $p->city))), 'plan' => $plans[$p->plan]['name'], 'at' => \Illuminate\Support\Carbon::parse($p->at, 'UTC')->toIso8601String()];
                    }
                }
                if ($cfg['useLiveActivity']) {
                    $count = fn ($event, $days) => DB::table('activity_events')->where('event', $event)->where('created_at', '>=', now()->subDays($days))->count();
                    foreach ([['resume_saved', 1, '📄', 'Resumes saved today', '%d resumes were saved on CVTara in the last 24 hours.', 5], ['resume_compared', 1, '🎯', 'ATS checks today', '%d resumes were checked against job descriptions in the last 24 hours.', 5], ['registered', 7, '👋', 'New this week', '%d job seekers joined CVTara in the last 7 days.', 5], ['purchase_verified', 7, '🚀', 'Plans started', '%d people started a plan in the last 7 days.', 3]] as [$event, $days, $icon, $title, $text, $min]) {
                        $n = $count($event, $days);
                        if ($n >= $min) {
                            $out[] = ['icon' => $icon, 'title' => $title, 'text' => sprintf($text, $n)];
                        }
                    }
                    foreach (Settings::plans() as $k => $p) {
                        if (($p['type'] ?? '') === 'plan' && ! empty($p['popular']) && ($p['mrp'] ?? 0) > $p['price']) {
                            $out[] = ['icon' => '⭐', 'title' => $p['name'], 'text' => sprintf('%s is ₹%s for %d days — save ₹%s today.', $p['name'], number_format($p['price']), $p['accessDays'], number_format($p['mrp'] - $p['price'])), 'href' => '/checkout.html?plan='.$k];
                        }
                    }
                }

                return $out;
            });

            return $ok(['settings' => ['enabled' => (bool) $cfg['enabled'], 'delaySeconds' => (int) $cfg['delaySeconds'], 'showSeconds' => (int) $cfg['showSeconds'], 'gapSeconds' => (int) $cfg['gapSeconds']], 'messages' => $messages, 'now' => gmdate('c')]);
        }
        if ($path === 'public-content') {
            $content = [];
            foreach (['legal', 'features', 'library', 'blog', 'integrations', 'seo', 'site'] as $k) {
                $content[$k] = Settings::get($k);
            }$content['plans'] = \App\Services\Interviews::withPerks(Settings::plans());
            $content['templateLib'] = \App\Services\TemplateLibrary::publicData();
            $content['jobLinks'] = (bool) (((array) Settings::get('speed', []))['jobLinks'] ?? false);
            $content['integrations']['measurementId'] = Settings::providers()['analytics']['measurementId'] ?? '';
            foreach ($content['blog'] as $slug => &$post) {
                if (! $post['published']) {
                    $post = ['published' => false];
                } elseif ($r->query('slug') !== $slug) {
                    $post['body'] = '';
                    $post['faq'] = '';
                }
            }

            return $ok(['content' => $content, 'reviews' => \App\Services\Reviews::published()]);
        }
        if ($path === 'traffic') {
            $cap('traffic', 60, 60, 'Too many requests. Please wait.');
            if (($d['consent'] ?? false) && Settings::get('integrations')['analytics']) {
                $p = $r->validate(['path' => ['required','regex:#^/[a-zA-Z0-9/_.-]*$#','not_regex:#\.\.#','max:200'], 'source' => 'required|in:direct,google,bing,social,referral,internal', 'campaign' => ['nullable', 'regex:/^[a-zA-Z0-9_.-]{1,60}$/'],
                    'ref' => ['nullable', 'regex:/^[a-z0-9.-]{1,120}$/i'], 'utm' => ['nullable', 'regex:/^[a-zA-Z0-9_.-]{1,60}$/']]);
                $campaign = $p['campaign'] ?? null;
                $host = isset($p['ref']) && $p['source'] !== 'internal' ? preg_replace('/^www\./', '', mb_strtolower($p['ref'])) : null;
                $p['source'] = \App\Services\Attribution::classify($p['source'], $host, $p['utm'] ?? null);
                unset($p['campaign'], $p['ref'], $p['utm']);
                if (! preg_match('/admin|workspace|setup/', $p['path'])) {
                    \App\Services\Attribution::touch($r, $p['path'], $p['source'], $campaign, $host);
                    $visitor = hash('sha256', $r->session()->getId());
                    if (! DB::table('page_views')->where('visitor_id', $visitor)->where('path', $p['path'])->where('created_at', '>', now()->subMinute())->exists()) {
                        DB::table('page_views')->insert([...$p, 'visitor_id' => $visitor, 'owner_id' => $r->user()?->id, 'ref_host' => $host, 'created_at' => now(), 'updated_at' => now()]);
                    }
                }
            }

            return $ok();
        }
        // 3.54.0 PartnerHub: public partner application (colleges, placement cells, coaching, companies, creators).
        if ($path === 'partners/apply' && ! $get) {
            $cap('partner-apply', 3, 3600, 'Too many applications from here. Please email us instead.');
            $v = $r->validate(['organisation' => 'required|string|min:2|max:160', 'kind' => 'required|in:'.implode(',', array_keys(\App\Services\Partners::KINDS)), 'name' => 'required|string|min:2|max:120',
                'email' => 'required|email|max:190', 'phone' => 'nullable|regex:/^[0-9+ -]{7,20}$/', 'city' => 'nullable|string|max:80', 'size' => 'nullable|string|max:40', 'message' => 'nullable|string|max:2000', 'website' => 'nullable|max:0']);

            return $ok(['id' => \App\Services\Partners::apply($v, $r), 'message' => 'Thank you. We will reply by email within two working days.']);
        }
        // 3.40.0: a staff member with a read-only customer view open is answered as that customer for allowed reads only.
        if ($u && ($viewed = \App\Services\SupportView::swap($r, $path))) {
            $u = $viewed;
            $id = $u->id;
        }
        abort_unless($u, 401);
        abort_if($u->blocked, 403);
        DB::table('profiles')->insertOrIgnore(['owner_id' => $id, 'name' => $u->name, 'created_at' => now(), 'updated_at' => now()]);
        if (str_starts_with($path, 'admin/')) {
            $adminPath = substr($path, 6);
            // 3.37.0: owner = everything; staff only what their role allows (config/permissions.php); unknown = owner only.
            \App\Services\Access::need($r, $adminPath);
            if ($adminPath === 'me' && $get) {
                return $ok(['role' => \App\Services\Access::role($u), 'roleName' => \App\Services\Access::isOwner($u) ? 'Owner' : (config('permissions.roles')[\App\Services\Access::role($u)]['name'] ?? ''), 'permissions' => \App\Services\Access::permissions($u), 'modules' => array_values(array_filter(array_keys(config('permissions.modules')), fn ($m) => \App\Services\Access::moduleAllowed($u, $m))), 'authenticator' => \App\Services\Totp::enabled($u)]);
            }
            if (str_starts_with($adminPath, 'team') || str_starts_with($adminPath, 'audit')) {
                return app(TeamAdminController::class)->run($r, $adminPath);
            }
            if ($get) {
                return app(AdminController::class)->run($r, $adminPath);
            }
            // Every console change goes to the append-only audit log, with settings before and after.
            $before = \App\Services\Audit::before($adminPath);
            try {
                $resp = app(AdminController::class)->run($r, $adminPath);
            } catch (\Throwable $e) {
                $code = $e instanceof \Symfony\Component\HttpKernel\Exception\HttpExceptionInterface ? $e->getStatusCode() : ($e instanceof ValidationException ? 422 : 500);
                \App\Services\Audit::afterWrite($r, $adminPath, $before, $code);
                throw $e;
            }
            \App\Services\Audit::afterWrite($r, $adminPath, $before, method_exists($resp, 'getStatusCode') ? $resp->getStatusCode() : 200);

            return $resp;
        }
        if (str_starts_with($path, 'security/totp/')) {
            return app(TeamAdminController::class)->totp($r, substr($path, 14));
        }
        // 3.40.0 Support Centre: the customer's own tickets and replies; the staff member's read-only view controls.
        if ($path === 'support/mine' && $get) {
            return $ok(['tickets' => \App\Services\SupportCentre::mine($u)]);
        }
        if (preg_match('#^support/mine/([a-f0-9-]{36})/reply$#', $path, $m) && $r->isMethod('POST')) {
            $cap('support-reply', 20, 3600, 'You have sent several replies. Please wait a while before sending another.');
            $v = $r->validate(['body' => 'required|string|min:2|max:5000']);
            $t = DB::table('support_reports')->where('id', $m[1])->where('owner_id', $id)->first();
            abort_unless($t, 404);
            \App\Services\SupportCentre::add($t->id, $id, 'customer', $v['body']);
            DB::table('support_reports')->where('id', $t->id)->update(['last_customer_at' => now(), 'updated_at' => now()] + (in_array($t->status, ['resolved', 'closed'], true) ? ['status' => 'new', 'resolved_at' => null] : []));

            return $ok(['tickets' => \App\Services\SupportCentre::mine($u)]);
        }
        // 3.41.0 Combined resume + cover letter service, downloads list and career goal.
        if ($path === 'service-requests' && $get) {
            return $ok(['requests' => \App\Services\ServiceRequests::mine($u)]);
        }
        if ($path === 'service-requests' && $r->isMethod('POST')) {
            \App\Services\EmailVerification::guard($u);
            $cap('service-request', 10, 3600, 'Please wait a while before starting another request.');
            $v = $r->validate(['resumeId' => ['required', 'regex:/^[a-f0-9-]{36}$/'], 'scanId' => ['nullable', 'regex:/^[a-f0-9-]{36}$/'], 'jobText' => 'required_without:scanId|nullable|string|max:40000', 'role' => 'nullable|string|max:160', 'company' => 'nullable|string|max:160', 'letterTemplate' => 'nullable|string|max:120']);
            if (! empty($v['letterTemplate'])) {
                abort_unless(\App\Services\TemplateLibrary::exists('letter', $v['letterTemplate']), 422, 'Choose one of the cover letter designs.');
            }

            return $ok(['request' => \App\Services\ServiceRequests::create($u, $v)]);
        }
        if (preg_match('#^service-requests/([a-f0-9-]{36})(?:/(run|retry|save))?$#', $path, $m)) {
            $act = $m[2] ?? '';
            if ($act === '') {
                abort_unless($get, 405);

                return $ok(['request' => \App\Services\ServiceRequests::show($u, $m[1])]);
            }
            abort_unless($r->isMethod('POST'), 405);
            $cap('service-run', 60, 60, 'Please wait a moment.');
            if ($act === 'save') {
                $v = $r->validate(['mode' => 'nullable|in:version,update']);

                return $ok(['request' => \App\Services\ServiceRequests::save($u, $m[1], $v['mode'] ?? 'version')]);
            }

            return $ok(['request' => $act === 'run' ? \App\Services\ServiceRequests::advance($u, $m[1]) : \App\Services\ServiceRequests::retry($u, $m[1])]);
        }
        // 3.51.0 Profile Boost: the customer approves the draft, or asks for one round of changes.
        if (preg_match('#^service-orders/([a-f0-9-]{36})/(approve|revise)$#', $path, $m) && $r->isMethod('POST')) {
            if ($m[2] === 'approve') {
                \App\Services\ProfileBoost::approve($u, $m[1]);
            } else {
                $cap('profile-boost-revise', 5, 3600, 'Please wait a while before asking again.');
                $v = $r->validate(['request' => 'required|string|min:10|max:1500']);
                \App\Services\ProfileBoost::revise($u, $m[1], $v['request']);
            }

            return $ok(['services' => \App\Services\Services::forUser($u->id)]);
        }
        // 3.54.0 Partner portal: the signed-in member's own organisation, numbers only.
        if ($path === 'partner' && $get) {
            return $ok(\App\Services\Partners::portal($u));
        }
        if (str_starts_with($path, 'partner/')) {
            $pm = \App\Services\Partners::membership($u);
            abort_unless($pm, 404);
            if (preg_match('#^partner/agreements/(\d+)/accept$#', $path, $mm) && ! $get) {
                $v = $r->validate(['hash' => 'required|string|size:64', 'name' => 'required|string|min:3|max:120', 'agree' => 'accepted']);
                \App\Services\PartnerOps::acceptAgreement($u, (int) $mm[1], $v['hash'], $v['name'], $r);

                return $ok(\App\Services\Partners::portal($u));
            }
            if ($path === 'partner/invites' && $get) {
                $rows = DB::table('partner_invites as i')->join('partner_links as l', 'l.id', '=', 'i.link_id')->where('i.partner_id', $pm->partner_id)->orderByDesc('i.id')->limit(2000)->get(['i.name', 'i.email', 'i.status', 'i.token', 'l.code', 'i.created_at']);

                return $ok(['invites' => $rows->map(fn ($x) => ['name' => $x->name, 'email' => $x->email, 'status' => $x->status, 'link' => $x->status === 'invited' ? url('/p/'.$x->code).'?i='.$x->token : '', 'created_at' => $x->created_at])]);
            }
            if ($path === 'partner/invites' && ! $get) {
                abort_unless($pm->role === 'manager', 403, 'Only a partner manager can upload students.');
                $cap('partner-invites', 20, 3600, 'Too many uploads. Please try again later.');
                $v = $r->validate(['linkId' => 'required|integer', 'text' => 'required_without:sheet|nullable|string|max:400000', 'sheet' => 'nullable|string|max:8000000', 'authority' => 'accepted'],
                    ['authority.accepted' => 'Please confirm that you may share these students\' details and have told them.']);
                $text = ! empty($v['sheet']) ? \App\Services\Outreach::sheetText((string) base64_decode($v['sheet'], true)) : (string) $v['text'];
                abort_if(trim($text) === '', 422, 'That file could not be read. Save it as .xlsx or CSV and try again.');

                return $ok(\App\Services\PartnerOps::invite($u, (int) $pm->partner_id, (int) $v['linkId'], $text, true));
            }
            if ($path === 'partner/payout' && ! $get) {
                return $ok(\App\Services\PartnerOps::requestPayout($u));
            }
            if (preg_match('#^partner/rewards/(\d+)/address$#', $path, $mm) && ! $get) {
                $v = $r->validate(['address' => 'required|string|min:15|max:600']);
                \App\Services\PartnerOps::rewardAddress($u, (int) $mm[1], $v['address']);

                return $ok(\App\Services\Partners::portal($u));
            }
            abort(404);
        }
        // 3.49.0 Interview practice: question practice (stored questions) and mock interviews with written feedback.
        if ($path === 'interviews' && $get) {
            return $ok(\App\Services\Interviews::overview($u));
        }
        if ($path === 'interviews/questions' && $get) {
            $v = $r->validate(['occupation' => 'required|string|max:80', 'band' => 'required|string|max:10']);

            return $ok(\App\Services\Interviews::questions($u, $v['occupation'], $v['band']));
        }
        // 3.57.0 role search, Research a company and revision mode.
        if ($path === 'interviews/roles' && $get) {
            return $ok(['roles' => \App\Services\InterviewPrep::findRoles((string) $r->query('q', ''))]);
        }
        if ($path === 'interviews/revision' && $get) {
            return $ok(\App\Services\InterviewPrep::revision($u));
        }
        if ($path === 'interviews/research' && $get) {
            return $ok(['research' => \App\Services\InterviewPrep::history($u), 'label' => \App\Services\InterviewPrep::LABEL]);
        }
        if (preg_match('#^interviews/research/(\d+)$#', $path, $m) && $get) {
            return $ok(['research' => \App\Services\InterviewPrep::show($u, (int) $m[1])]);
        }
        if ($path === 'interviews/research' && $r->isMethod('POST')) {
            \App\Services\EmailVerification::guard($u);
            $cap('company-research', 10, 3600, 'Please wait a while before researching another company.');
            $v = $r->validate(['company' => 'required|string|max:160', 'url' => 'required|string|max:500', 'occupation' => 'nullable|string|max:80']);

            return $ok(['research' => \App\Services\InterviewPrep::research($u, $v['company'], $v['url'], $v['occupation'] ?? null)]);
        }
        if ($path === 'interviews/start' && $r->isMethod('POST')) {
            \App\Services\EmailVerification::guard($u);
            $cap('interview-start', 10, 3600, 'Please wait a while before starting another mock interview.');
            $v = $r->validate(['occupation' => 'required|string|max:80', 'band' => 'required|string|max:10', 'objective' => 'nullable|string|max:20', 'company' => 'nullable|string|max:120']);

            return $ok(['session' => \App\Services\Interviews::start($u, $v)]);
        }
        if (preg_match('#^interviews/([a-f0-9-]{36})(?:/(answer|submit|challenge))?$#', $path, $m)) {
            $act = $m[2] ?? '';
            if ($act === '') {
                abort_unless($get, 405);

                return $ok(['session' => \App\Services\Interviews::session($u, $m[1])]);
            }
            abort_unless($r->isMethod('POST'), 405);
            $cap('interview-'.$act, 120, 600, 'Please wait a moment.');
            if ($act === 'answer') {
                $v = $r->validate(['position' => 'required|integer|min:1|max:10', 'answer' => 'present|nullable|string|max:3000', 'seconds' => 'nullable|integer|min:0|max:7200']);
                \App\Services\Interviews::answer($u, $m[1], (int) $v['position'], (string) ($v['answer'] ?? ''), isset($v['seconds']) ? (int) $v['seconds'] : null);

                return $ok();
            }
            if ($act === 'challenge') {
                $v = $r->validate(['note' => 'required|string|min:5|max:1500']);
                \App\Services\Interviews::challenge($u, $m[1], $v['note']);

                return $ok(['session' => \App\Services\Interviews::session($u, $m[1])]);
            }

            return $ok(['session' => \App\Services\Interviews::submit($u, $m[1])]);
        }
        if ($path === 'downloads' && $get) {
            $rows = DB::table('product_usage')->where('owner_id', $id)->whereIn('action', ['doc_resume', 'doc_letter'])->orderByDesc('created_at')->limit(100)->get(['action', 'reference', 'created_at']);
            $ids = $rows->map(fn ($x) => explode('|', (string) $x->reference)[0])->unique()->values();
            $titles = DB::table('resume_drafts')->where('owner_id', $id)->whereIn('id', $ids)->pluck('title', 'id')->union(DB::table('cover_letter_drafts')->where('owner_id', $id)->whereIn('id', $ids)->pluck('title', 'id'));

            return $ok(['downloads' => $rows->map(function ($x) use ($titles) {
                [$doc, $rev] = array_pad(explode('|', (string) $x->reference), 2, '');

                return ['kind' => $x->action === 'doc_resume' ? 'resume' : 'letter', 'id' => $doc, 'version' => (int) $rev, 'title' => (string) ($titles[$doc] ?? 'Removed document'), 'exists' => isset($titles[$doc]), 'at' => (string) $x->created_at];
            })->values()]);
        }
        if ($path === 'profile/goal' && $r->isMethod('POST')) {
            $v = $r->validate(['goal' => 'required|in:first_job,new_job,switch_career,promotion,abroad,exploring', 'role' => 'nullable|string|max:120']);
            $set = ['career_goal' => $v['goal'], 'updated_at' => now()];
            if (trim((string) ($v['role'] ?? '')) !== '' && \Illuminate\Support\Facades\Schema::hasColumn('profiles', 'target_role')) {
                $set['target_role'] = trim($v['role']);
            }
            if (! DB::table('profiles')->where('owner_id', $id)->exists()) {
                DB::table('profiles')->insert(['owner_id' => $id, 'created_at' => now()] + $set);
            } else {
                DB::table('profiles')->where('owner_id', $id)->update($set);
            }
            Settings::audit($id, 'career_goal_set', $v['goal']);

            return $ok();
        }
        if ($path === 'support-view' && $get) {
            return $ok(\App\Services\SupportView::status($r));
        }
        if ($path === 'support-view/end' && $r->isMethod('POST')) {
            \App\Services\SupportView::end($r);

            return $ok(['active' => false]);
        }
        if ($path === 'referral-rewards' && $get) {
            return $ok(ReferralRewards::status($u));
        }
        if (str_starts_with($path, 'referral-rewards/')) {
            abort_unless($r->isMethod('POST'), 405);
            if ($path === 'referral-rewards/claim') {
                $r->validate(['milestone' => 'required|integer|in:5']);
                ReferralRewards::claim($u, $r->integer('milestone'));
            } else {
                abort(404);
            }

            return $ok();
        }
        if ($path === 'security/status') {
            return $ok(['verified' => (bool) $u->email_verified_at, 'recent' => config('app.preview') || $r->session()->get('sensitive_until', 0) > now()->timestamp && $r->session()->get('sensitive_user') === $u->id]);
        }
        if ($path === 'security/send-code') {
            AccountSecurity::send($r);

            return $ok();
        }
        if ($path === 'security/verify-code') {
            AccountSecurity::verify($r);

            return $ok();
        }
        if ($path === 'referrals/creator') {
            $v = $r->validate(['links' => 'required|array|min:1|max:5', 'links.*' => 'required|url:https|max:500', 'audience' => 'required|string|min:10|max:500', 'consent' => 'accepted']);
            AffiliateProfiles::creator($u, $v);

            return $ok();
        }
        if ($path === 'referrals/payout-profile') {
            AccountSecurity::requireRecent($r);
            $v = $r->validate(['name' => 'required|string|min:3|max:100', 'phone' => 'required|regex:/^[6-9][0-9]{9}$/', 'address' => 'required|string|min:10|max:500', 'country' => 'required|in:IN', 'method' => 'required|in:upi,bank', 'upi' => 'required_if:method,upi|nullable|regex:/^[a-zA-Z0-9._-]{2,100}@[a-zA-Z0-9]{2,40}$/', 'account' => 'required_if:method,bank|nullable|regex:/^[0-9]{9,18}$/', 'ifsc' => 'required_if:method,bank|nullable|regex:/^[A-Z]{4}0[A-Z0-9]{6}$/', 'pan' => (Referrals::config()['requirePan'] ? 'required' : 'nullable').'|regex:/^[A-Z]{5}[0-9]{4}[A-Z]$/', 'consent' => 'accepted']);
            AffiliateProfiles::save($u, $v);

            return $ok();
        }
        if ($path === 'profile' && $get) {
            $p = DB::table('profiles')->where('owner_id', $id)->first();
            $p->email = $u->email;

            return $ok(['profile' => $p, 'isOwner' => \App\Services\Access::isStaff($u), 'consoleRole' => \App\Services\Access::role($u), 'isPaid' => (bool) (Settings::access($id)['paid'] ?? false) || (bool) $u->is_admin, 'user' => ['id' => $id, 'email' => $u->email]]);
        }
        if ($path === 'profile') {
            $v = $r->validate(['name' => 'required|string|max:120', 'phone' => 'nullable|string|max:40', 'language' => 'sometimes|in:en', 'experienceLevel' => 'required|in:fresher,experienced', 'profession' => 'required|string|max:120', 'category' => 'required|in:Technology,HR & Recruitment,Sales & Marketing,Finance,Operations,Education,Healthcare,Design,Other', 'experienceYears' => 'required|integer|min:0|max:60', 'city' => 'nullable|string|max:120', 'marketingConsent' => 'required|boolean']);
            DB::table('profiles')->where('owner_id', $id)->update(['name' => $v['name'], 'phone' => $v['phone'] ?? '', 'language' => 'en', 'experience_level' => $v['experienceLevel'], 'profession' => $v['profession'], 'category' => $v['category'], 'experience_years' => $v['experienceLevel'] === 'fresher' ? 0 : $v['experienceYears'], 'city' => $v['city'] ?? '', 'marketing_consent' => $v['marketingConsent'], 'onboarding_done' => true, 'updated_at' => now()]);
            $u->name = $v['name'];
            $u->save();
            Settings::audit($id, 'profile_completed');

            return $ok();
        }
        if ($path === 'writing/check' && $r->isMethod('POST')) {
            $v = $r->validate(['type' => 'required|in:resume,letter', 'id' => 'nullable|uuid', 'data' => 'required_without:id|array', 'full' => 'sometimes|boolean']);
            $rk = 'writing:'.$id;
            abort_if(\Illuminate\Support\Facades\RateLimiter::tooManyAttempts($rk, 30), 429, 'Too many checks in a minute. Wait a moment and try again.');
            \Illuminate\Support\Facades\RateLimiter::hit($rk, 60);
            $data = $v['data'] ?? null;
            if (! empty($v['id'])) {
                $row = DB::table($v['type'] === 'resume' ? 'resume_drafts' : 'cover_letter_drafts')->where('owner_id', $id)->where('id', $v['id'])->first(['content_json']);
                abort_unless($row, 404);
                $data = json_decode((string) $row->content_json, true) ?: [];
            }
            abort_if(strlen((string) json_encode($data)) > 400000, 413);

            return $ok(['check' => \App\Services\WritingCheck::run($v['type'], (array) $data, $id, (bool) ($v['full'] ?? false))]);
        }
        // One-click cover letter: a complete letter from a saved resume and a job (pasted text, or the job of an ATS check).
        if ($path === 'letters/draft' && $r->isMethod('POST')) {
            $v = $r->validate(['resumeId' => ['required', 'regex:/^[a-f0-9-]{36}$/'], 'scanId' => ['nullable', 'regex:/^[a-f0-9-]{36}$/'], 'role' => 'nullable|string|max:160', 'company' => 'nullable|string|max:160', 'recipient' => 'nullable|string|max:180', 'jobText' => 'nullable|string|max:40000']);
            abort_unless(Settings::get('features')['letter']['enabled'], 403);
            $key = 'letter-draft:'.$id;
            if (\Illuminate\Support\Facades\RateLimiter::tooManyAttempts($key, 8)) {
                throw ValidationException::withMessages(['letter' => 'Please wait a moment before writing another letter.']);
            }
            \Illuminate\Support\Facades\RateLimiter::hit($key, 60);
            $resume = DB::table('resume_drafts')->where('id', $v['resumeId'])->where('owner_id', $id)->first(['content_json', 'job_description', 'role', 'company']);
            abort_unless($resume, 422, 'Choose one of your saved resumes.');
            $job = ['role' => $v['role'] ?? '', 'company' => $v['company'] ?? '', 'recipient' => $v['recipient'] ?? '', 'text' => (string) ($v['jobText'] ?? '')];
            if (! empty($v['scanId'])) {
                $sc = DB::table('ats_scans')->where('id', $v['scanId'])->where('owner_id', $id)->where('status', 'done')->first(['job_text', 'job_title', 'company']);
                abort_unless($sc, 422, 'That ATS check was not found.');
                $job = [...$job, 'text' => trim($job['text']) !== '' ? $job['text'] : (string) $sc->job_text, 'role' => $job['role'] ?: (string) $sc->job_title, 'company' => $job['company'] ?: (string) $sc->company];
            }
            // A resume tailored for a job keeps that job's text, role and company.
            $job = [...$job, 'text' => trim($job['text']) !== '' ? $job['text'] : (string) ($resume->job_description ?? ''), 'role' => $job['role'] ?: (string) ($resume->role ?? ''), 'company' => $job['company'] ?: (string) ($resume->company ?? '')];
            $data = json_decode((string) $resume->content_json, true) ?: [];
            abort_if(mb_strlen(\App\Services\AtsEngine::resumeText($data)) < 60, 422, 'This resume has too little content to write from. Add your experience in the builder first.');
            $out = \App\Services\CoverLetterWriter::draft($u, $data, $job);
            Settings::audit($id, 'cover_letter_drafted', (string) ($v['scanId'] ?? ''));

            return $ok($out);
        }
        if ($path === 'ai/status' && $get) {
            return $ok(['ai' => \App\Services\TaraAI::status($u)]);
        }
        if ($path === 'ai/suggest' && $r->isMethod('POST')) {
            if (\App\Services\TaraAI::enabled()) {
                $v = $r->validate(['task' => 'required|in:'.implode(',', array_keys(\App\Services\TaraAI::TASKS)), 'text' => 'required|string|min:20|max:12000', 'context' => 'nullable|string|max:8000', 'consent' => 'accepted']);
                $key = 'tara-ai:'.$id;
                if (\Illuminate\Support\Facades\RateLimiter::tooManyAttempts($key, 6)) {
                    throw \Illuminate\Validation\ValidationException::withMessages(['ai' => 'Please wait a moment before asking Tara again.']);
                }
                \Illuminate\Support\Facades\RateLimiter::hit($key, 60);

                return $ok(['suggestion' => \App\Services\TaraAI::suggest($u, $v), 'left' => \App\Services\TaraAI::left($u)]);
            }
            // One approved writing service only (3.36.0): the old second-provider path was removed.
            abort(422, 'CVTara team writing help is not switched on yet. Your editor works as usual.');
        }
        if (str_starts_with($path, 'tara/')) {
            return $this->tara($r, substr($path, 5));
        }
        if ($path === 'credits/history' && $get) {
            // What used each credit: clean downloads, ATS scans and the free primary resume, newest first.
            $rows = DB::table('product_usage')->where('owner_id', $id)->whereIn('action', ['doc_resume', 'doc_letter', 'ats_scan', 'primary_free'])->orderByDesc('created_at')->limit(50)->get(['action', 'reference', 'created_at']);
            $ids = $rows->map(fn ($x) => explode('|', (string) $x->reference)[0])->unique()->values()->all();
            $names = DB::table('resume_drafts')->where('owner_id', $id)->whereIn('id', $ids)->pluck('title', 'id')->all() + DB::table('ats_scans')->where('owner_id', $id)->whereIn('id', $ids)->pluck('job_title', 'id')->all();
            if (\Illuminate\Support\Facades\Schema::hasTable('cover_letter_drafts')) {
                $names += DB::table('cover_letter_drafts')->where('owner_id', $id)->whereIn('id', $ids)->pluck('title', 'id')->all();
            }
            $what = ['doc_resume' => 'Resume download', 'doc_letter' => 'Cover-letter download', 'ats_scan' => 'ATS scan', 'primary_free' => 'Primary resume (free once)'];

            return $ok(['history' => $rows->map(fn ($x) => ['what' => $what[$x->action], 'item' => (string) ($names[explode('|', (string) $x->reference)[0]] ?? ''), 'credits' => $x->action === 'primary_free' ? 0 : 1, 'at' => $x->created_at])->all(), 'credits' => Credits::status($id)]);
        }
        if ($path === 'allowance') {
            $a = Settings::access($id);
            $l = $a['limits'];
            $pid = $a['purchase']?->id;
            $exports = $pid ? DB::table('product_usage')->where('owner_id', $id)->where('action', 'export')->where('reference', 'like', $pid.':%')->count() : 0;
            $cs = Credits::status($id);
            $scans = $a['paid'] ? $cs['scans']['used'] : DB::table('ats_scans')->where('owner_id', $id)->where('status', '!=', 'void')->count();
            $planName = Settings::planLabel($a);
            unset($a['purchase']);

            return $ok([...$a, 'emailVerified' => ! \App\Services\EmailVerification::required($r->user()), 'jobLinks' => (bool) (((array) Settings::get('speed', []))['jobLinks'] ?? false), 'planName' => $planName, 'daysLeft' => $a['accessUntil'] ? max(0, (int) ceil((strtotime($a['accessUntil']) - time()) / 86400)) : 0, 'credits' => $cs, 'caps' => ['resumes' => (int) $l['savedResumes'] + 1, 'letters' => (int) $l['savedLetters'], 'atsScans' => $cs['scans']['total'], 'exports' => null], 'used' => ['exports' => $exports, 'savedResumes' => DB::table('resume_drafts')->where('owner_id', $id)->count(), 'savedLetters' => DB::table('cover_letter_drafts')->where('owner_id', $id)->count(), 'atsScans' => $scans, 'dailyMatches' => DB::table('ats_scans')->where('owner_id', $id)->where('status', '!=', 'void')->whereDate('created_at', today())->count()]]);
        }
        if ($path === 'resumes/import') {
            abort_unless($r->isMethod('POST'), 405);
            $cap('resume-import', 20, 600, 'Too many uploads in a few minutes. Wait a little and try again.');

            return $this->importResume($r);
        }
        if (preg_match('#^resumes/([a-f0-9-]{36})/quality$#', $path, $m) && $get) {
            $row = DB::table('resume_drafts')->where('owner_id', $id)->where('id', $m[1])->first(['content_json']);
            abort_unless($row, 404);

            return $ok(['quality' => \App\Services\ResumeQuality::score(json_decode($row->content_json, true) ?: [])]);
        }
        if ($path === 'whats-new' && $get) {
            return $ok(\App\Services\WhatsNew::forUser($u));
        }
        if ($path === 'whats-new/seen') {
            abort_unless($r->isMethod('POST'), 405);
            $cap('whats-new-seen', 20, 600, 'Please try again in a few minutes.');
            \App\Services\WhatsNew::markSeen($id);

            return $ok();
        }
        if ($path === 'notifications') {
            if ($r->isMethod('POST')) {
                $ids = array_filter((array) $r->input('ids', []), fn ($x) => is_string($x) && preg_match('/^[a-f0-9-]{36}$/', $x));
                DB::table('notifications')->where('owner_id', $id)->when($ids, fn ($q) => $q->whereIn('id', $ids))->whereNull('read_at')->update(['read_at' => now()]);

                return $ok();
            }

            return $ok(['notifications' => DB::table('notifications')->where('owner_id', $id)->whereNull('read_at')->orderByDesc('created_at')->limit(10)->get(['id', 'kind', 'title', 'body', 'link', 'created_at'])]);
        }
        if (preg_match('#^resumes/([a-f0-9-]{36})/tailor$#', $path, $m) && $r->isMethod('POST')) {
            // the CVTara team rewrites this resume for one checked job; the builder shows it for review, nothing is saved here
            $v = $r->validate(['scanId' => ['required', 'regex:/^[a-f0-9-]{36}$/'], 'consent' => 'accepted']);
            $row = DB::table('resume_drafts')->where('id', $m[1])->where('owner_id', $id)->first();
            abort_unless($row, 404);
            $sc = DB::table('ats_scans')->where('id', $v['scanId'])->where('owner_id', $id)->where('status', 'done')->first();
            abort_unless($sc, 422, 'That ATS check was not found.');
            if (\Illuminate\Support\Facades\RateLimiter::tooManyAttempts('tara-ai:'.$id, 6)) {
                throw ValidationException::withMessages(['ai' => 'Please wait a moment before asking the CVTara team again.']);
            }
            \Illuminate\Support\Facades\RateLimiter::hit('tara-ai:'.$id, 60);

            return $ok(['tailored' => \App\Services\ResumeTailor::run($u, json_decode((string) $row->content_json, true) ?: [], (string) $sc->job_text, json_decode((string) $sc->result_json, true) ?: [])]);
        }
        // 3.52.0 resume version history: list, read one version, restore it.
        if (preg_match('#^resumes/([a-f0-9-]{36})/versions(?:/([a-f0-9-]{36})(/restore)?)?$#', $path, $m)) {
            if (empty($m[2])) {
                abort_unless($get, 405);

                return $ok(['versions' => \App\Services\ResumeVersions::list($id, $m[1])]);
            }
            if (empty($m[3])) {
                abort_unless($get, 405);

                return $ok(['version' => \App\Services\ResumeVersions::show($id, $m[1], $m[2])]);
            }
            abort_unless($r->isMethod('POST'), 405);

            return $ok(\App\Services\ResumeVersions::restore($id, $m[1], $m[2]));
        }
        if (preg_match('#^resumes/([a-f0-9-]{36})/(primary|variant)$#', $path, $m)) {
            abort_unless($r->isMethod('POST'), 405);

            return $this->primaryTools($r, $m[1], $m[2]);
        }
        if ($path === 'account/export') {
            return $ok(['export' => $this->accountExport($u)]);
        }
        if ($path === 'account/delete') {
            abort_unless($r->isMethod('POST'), 405);
            $r->validate(['password' => 'required|string|max:200', 'confirm' => 'required|in:DELETE']);
            abort_unless(\Illuminate\Support\Facades\Hash::check($r->password, $u->password), 422, 'The password is incorrect.');
            $this->deleteAccount($u);
            \Illuminate\Support\Facades\Auth::logout();
            $r->session()->invalidate();
            $r->session()->regenerateToken();

            return $ok(['redirect' => '/']);
        }
        if (preg_match('#^(resumes|letters)(?:/([a-f0-9-]{36}))?$#', $path, $m)) {
            return $this->documents($r, $m[1], $m[2] ?? null);
        }
        // 3.56.0 "Is this the right job?" (V7 §13, AT-11): read the posting and show what was understood. No scan is used.
        if ($path === 'ats/read' && $r->isMethod('POST')) {
            $v = $r->validate(['source' => 'required|in:link,file,text', 'url' => 'nullable|string|max:1000', 'text' => 'nullable|string|max:60000', 'title' => 'nullable|string|max:180', 'company' => 'nullable|string|max:180']);
            abort_unless(Settings::get('features')['match']['enabled'], 403);
            $url = '';
            $details = [];
            $title = trim((string) ($v['title'] ?? ''));
            $company = trim((string) ($v['company'] ?? ''));
            if ($v['source'] === 'link') {
                abort_unless((((array) Settings::get('speed', []))['jobLinks'] ?? false), 422, 'Job links are not available yet. Paste the job text or upload a PDF.');
                abort_if(empty($v['url']), 422, 'Paste the link of the job posting.');
                if (\Illuminate\Support\Facades\RateLimiter::tooManyAttempts('ats-link:'.$id, (int) env('ATS_LINK_RATE', 10))) {
                    throw ValidationException::withMessages(['url' => 'Too many job links in a minute. Wait a moment and try again.']);
                }
                \Illuminate\Support\Facades\RateLimiter::hit('ats-link:'.$id, 60);
                \App\Services\Traffic::guardHeavy();
                $page = JobPage::fetch($v['url']);
                $text = $page['text'];
                $url = JobPage::canonical((string) $v['url']);
                $details = $page['details'] ?? [];
                $title = $title ?: $page['title'];
                $company = $company ?: $page['company'];
                // The check that follows reuses this reading instead of opening the link again.
                $r->session()->put('ats.read', ['url' => $url, 'text' => $text, 'title' => $page['title'], 'company' => $page['company'], 'details' => $details, 'at' => time()]);
            } else {
                $text = mb_substr(trim((string) ($v['text'] ?? '')), 0, 40000);
                abort_if(mb_strlen($text) < 80, 422, 'The job description is too short to review. Include the responsibilities and requirements.');
            }

            return $ok(['job' => \App\Services\JobFields::read($text, $title, $company, $url, $details)]);
        }
        if ($path === 'ats/scan' && $r->isMethod('POST')) {
            $v = $r->validate(['resumeId' => ['required', 'regex:/^[a-f0-9-]{36}$/'], 'source' => 'required|in:link,file,text', 'url' => 'nullable|string|max:1000', 'text' => 'nullable|string|max:60000', 'title' => 'nullable|string|max:180', 'company' => 'nullable|string|max:180']);
            abort_unless(Settings::get('features')['match']['enabled'], 403);
            \App\Services\EmailVerification::guard($r->user());
            if ($v['source'] === 'link' && ! (((array) Settings::get('speed', []))['jobLinks'] ?? false)) {
                return response()->json(['ok' => false, 'error' => 'Job links are not available yet. Paste the job text or upload a PDF.'], 422);
            }
            \App\Services\Traffic::guardHeavy();
            $resume = DB::table('resume_drafts')->where('id', $v['resumeId'])->where('owner_id', $id)->first();
            abort_unless($resume, 422, 'Choose one of your saved resumes.');
            $access = Settings::access($id);
            $today = DB::table('ats_scans')->where('owner_id', $id)->whereDate('created_at', today())->count();
            $cap = $access['paid'] ? (int) ($access['limits']['dailyMatches'] ?? 100) : min((int) Settings::get('features')['match']['limit'], (int) $access['limits']['dailyMatches']);
            if ($today >= $cap) {
                throw ValidationException::withMessages(['limit' => $access['paid'] ? 'Daily ATS check limit reached. Try again tomorrow.' : 'Your free ATS checks for today are used. Try again tomorrow or choose a plan for more scans.']);
            }
            if (! Credits::scanAvailable($id)) {
                throw ValidationException::withMessages(['limit' => Credits::outOf('ATS scans')]);
            }
            $title = trim((string) ($v['title'] ?? ''));
            $company = trim((string) ($v['company'] ?? ''));
            $details = [];
            if ($v['source'] === 'link') {
                if (empty($v['url'])) {
                    throw ValidationException::withMessages(['url' => 'Paste the link of the job posting.']);
                }
                if (\Illuminate\Support\Facades\RateLimiter::tooManyAttempts('ats-link:'.$id, (int) env('ATS_LINK_RATE', 10))) {
                    throw ValidationException::withMessages(['url' => 'Too many job links in a minute. Wait a moment and try again.']);
                }
                $cached = (array) $r->session()->get('ats.read', []);
                $page = ($cached['url'] ?? '') === JobPage::canonical((string) $v['url']) && (int) ($cached['at'] ?? 0) > time() - 900 ? $cached : null;
                if (! $page) {
                    \Illuminate\Support\Facades\RateLimiter::hit('ats-link:'.$id, 60);
                    $page = JobPage::fetch($v['url']);
                }
                $text = $page['text'];
                $title = $title ?: $page['title'];
                $company = $company ?: $page['company'];
                $details = $page['details'] ?? [];
            } else {
                $text = mb_substr(trim((string) ($v['text'] ?? '')), 0, 40000);
                if (mb_strlen($text) < 80) {
                    throw ValidationException::withMessages(['text' => 'The job description is too short to review. Include the responsibilities and requirements.']);
                }
            }
            if ($title === '' || $company === '') {
                [$guessTitle, $guessCompany] = \App\Services\AtsEngine::headline($text);
                $title = $title ?: $guessTitle;
                $company = $company ?: $guessCompany;
            }
            try {
                $report = \App\Services\AtsEngine::report(json_decode((string) $resume->content_json, true) ?: [], $text, $title);
            } catch (\InvalidArgumentException $e) {
                throw ValidationException::withMessages(['text' => $e->getMessage()]);
            }
            $report['details'] = $details;
            $report['jd'] = \App\Services\JobFields::read($text, $title, $company, $v['source'] === 'link' ? JobPage::canonical((string) $v['url']) : '', $details);
            $report['jd']['confirmed'] = $r->boolean('confirmed');
            $report['jd']['confirmedAt'] = $r->boolean('confirmed') ? now()->toIso8601String() : null;
            $resumeData = json_decode((string) $resume->content_json, true) ?: [];
            $report['resumeHash'] = \App\Services\AtsEngine::fingerprint($resumeData);
            $scanId = (string) Str::uuid();
            DB::transaction(function () use ($id, $scanId, $v, $text, $title, $company, $report) {
                User::whereKey($id)->lockForUpdate()->first();
                Credits::reserveScan($id, $scanId);
                DB::table('ats_scans')->insert(['id' => $scanId, 'owner_id' => $id, 'resume_id' => $v['resumeId'], 'source' => $v['source'], 'job_url' => $v['source'] === 'link' ? mb_substr(JobPage::canonical((string) $v['url']), 0, 1000) : '', 'job_title' => $title, 'company' => $company, 'job_text' => $text, 'score' => $report['score'], 'result_json' => json_encode($report), 'status' => 'done', 'created_at' => now(), 'updated_at' => now()]);
            });
            Settings::audit($id, 'resume_compared');

            return $ok(['scanId' => $scanId, 'title' => $title, 'company' => $company, 'jobUrl' => $v['source'] === 'link' ? JobPage::canonical((string) $v['url']) : '', 'report' => $report, 'resumeTitle' => $resume->title, 'sameContent' => $this->sameContent($id, $resume, $report['resumeHash'], $text, $scanId), 'credits' => Credits::status($id)]);
        }
        if ($path === 'ats/scans' && $get) {
            $rows = DB::table('ats_scans')->where('ats_scans.owner_id', $id)->where('ats_scans.status', 'done')->leftJoin('resume_drafts', 'resume_drafts.id', '=', 'ats_scans.resume_id')->orderByDesc('ats_scans.created_at')->limit(30)->get(['ats_scans.id', 'ats_scans.resume_id', 'ats_scans.source', 'ats_scans.job_url', 'ats_scans.job_title', 'ats_scans.company', 'ats_scans.score', 'ats_scans.created_at', 'resume_drafts.title as resume_title']);

            return $ok(['scans' => $rows->map(fn ($x) => ['id' => $x->id, 'resumeId' => $x->resume_id, 'resumeTitle' => $x->resume_title, 'source' => $x->source, 'jobUrl' => $x->job_url, 'title' => $x->job_title, 'company' => $x->company, 'score' => $x->score, 'createdAt' => $x->created_at]), 'credits' => Credits::status($id)]);
        }
        if (preg_match('#^ats/scans/([a-f0-9-]{36})$#', $path, $m) && $get) {
            $x = DB::table('ats_scans')->where('id', $m[1])->where('owner_id', $id)->where('status', 'done')->first();
            abort_unless($x, 404);

            return $ok(['scan' => ['id' => $x->id, 'resumeId' => $x->resume_id, 'resumeTitle' => DB::table('resume_drafts')->where('id', $x->resume_id)->where('owner_id', $id)->value('title'), 'source' => $x->source, 'jobUrl' => $x->job_url, 'jobText' => $x->job_text, 'title' => $x->job_title, 'company' => $x->company, 'score' => $x->score, 'report' => json_decode((string) $x->result_json, true), 'createdAt' => $x->created_at]]);
        }
        if ($path === 'applications' && $get) {
            return $ok(['applications' => DB::table('applications')->where('owner_id', $id)->orderByDesc('updated_at')->get()]);
        }
        if ($path === 'applications' && $r->isMethod('POST')) {
            $v = $r->validate(['company' => 'required|string|max:180', 'role' => 'required|string|max:180', 'stage' => 'required|in:saved,applied,interview,offer,closed', 'jobUrl' => 'nullable|url:http,https|max:1000', 'appliedAt' => 'nullable|date_format:Y-m-d', 'followUp' => 'nullable|date_format:Y-m-d', 'resumeId' => 'nullable|uuid', 'notes' => 'nullable|string|max:8000', 'id' => 'nullable|uuid', 'revision' => 'nullable|integer', 'remindersOff' => 'nullable|boolean']);
            $result = DB::transaction(function () use ($v, $id) {
                User::whereKey($id)->lockForUpdate()->first();
                $feature = Settings::get('features')['tracker'];
                abort_unless($feature['enabled'], 403);
                if (! empty($v['resumeId'])) {
                    abort_unless(DB::table('resume_drafts')->where('owner_id', $id)->where('id', $v['resumeId'])->exists(), 422);
                }$record = ['owner_id' => $id, 'company' => $v['company'], 'role' => $v['role'], 'stage' => $v['stage'], 'job_url' => $v['jobUrl'] ?? '', 'applied_at' => $v['appliedAt'] ?? null, 'follow_up' => $v['followUp'] ?? null, 'resume_id' => $v['resumeId'] ?? null, 'notes' => $v['notes'] ?? '', 'updated_at' => now()];
                if (array_key_exists('remindersOff', $v) && $v['remindersOff'] !== null) {
                    $record['reminders_off'] = (bool) $v['remindersOff'];
                }
                if (in_array($v['stage'], ['offer', 'closed'], true)) {
                    $record['next_reminder_at'] = null;
                }
                $aid = $v['id'] ?? (string) Str::uuid();
                if (! empty($v['id'])) {
                    abort_unless(DB::table('applications')->where('id', $aid)->where('owner_id', $id)->where('revision', $v['revision'] ?? 0)->update([...$record, 'revision' => DB::raw('revision+1')]), 409);
                } else {
                    abort_if(DB::table('applications')->where('owner_id', $id)->count() >= $feature['limit'], 422);
                    DB::table('applications')->insert([...$record, 'id' => $aid, 'revision' => 1, 'created_at' => now()]);
                }

                return $aid;
            });
            \App\Services\ResumeVersions::freezeForApplication($id, $result); // 3.52.0: the resume copy used for this application

            return $ok(['id' => $result]);
        }
        if (preg_match('#^applications/([a-f0-9-]{36})$#', $path, $m) && $r->isMethod('DELETE')) {
            abort_unless(DB::table('applications')->where('id', $m[1])->where('owner_id', $id)->where('revision', $r->input('revision'))->delete(), 409);

            return $ok();
        }
        if ($path === 'purchases') {
            return $ok(['purchases' => \App\Services\Refunds::forUser($id), 'services' => \App\Services\Services::forUser($id), 'refundDays' => \App\Services\Refunds::DAYS]);
        }
        if ($path === 'refunds') {
            abort_unless($r->isMethod('POST'), 405);
            $v = $r->validate(['purchaseId' => 'required|uuid', 'reason' => 'nullable|string|max:1000']);
            $key = 'refund-try:'.$id;
            abort_if(\Illuminate\Support\Facades\RateLimiter::tooManyAttempts($key, 5), 429, 'Too many attempts. Wait a few minutes.');
            \Illuminate\Support\Facades\RateLimiter::hit($key, 600);

            return $ok(['refund' => \App\Services\Refunds::request($u, $v['purchaseId'], (string) ($v['reason'] ?? ''))]);
        }
        if ($path === 'wallet' && $get) {
            return $ok(\App\Services\Wallet::summary($id));
        }
        if ($path === 'checkout/quote') {
            abort_unless($r->isMethod('POST'), 405);
            $v = $r->validate(['plan' => 'required|in:'.implode(',', Settings::paidPlanKeys()), 'coupon' => 'nullable|string|max:30', 'useWallet' => 'nullable|boolean']);
            Payments::guardAddon($u, $v['plan']);
            if (! empty($v['coupon'])) {
                $rk = 'coupon-try:'.$u->id;
                abort_if(\Illuminate\Support\Facades\RateLimiter::tooManyAttempts($rk, 10), 429, 'Too many coupon attempts. Wait a minute.');
                \Illuminate\Support\Facades\RateLimiter::hit($rk, 60);
            }

            return $ok([...BusinessControls::quote($v['plan'], $v['coupon'] ?? '', $u->id, $r->boolean('useWallet', true)), 'gateways' => Payments::publicGateways()]);
        }
        if ($path === 'checkout/start') {
            $cap('checkout-start', 12, 600, 'Too many checkout attempts. Wait a few minutes and try again.');
            \App\Services\EmailVerification::guard($r->user());
            $r->validate(['plan' => 'required|in:'.implode(',', Settings::paidPlanKeys()), 'showInActivity' => 'nullable|boolean', 'useWallet' => 'nullable|boolean', 'gateway' => 'nullable|in:'.implode(',', array_keys(Payments::GATEWAYS))]);
            if ($r->has('showInActivity')) {
                DB::table('profiles')->where('owner_id', $id)->update(['show_in_activity' => $r->boolean('showInActivity')]);
            }
            Payments::guardAddon($u, $r->plan);

            return $ok(Payments::start($u, $r->plan, (string) $r->input('coupon', ''), $r->boolean('useWallet', true), (string) $r->input('gateway', '')));
        }
        if ($path === 'checkout/verify' && config('app.preview') && $r->input('provider') === 'demo') {
            $r->validate(['orderId' => 'required|string|max:80']);
            Payments::demoVerify($u, $r->orderId);

            return $ok();
        }
        if (str_starts_with($path, 'checkout/verify')) {
            $cap('checkout-verify', 30, 60, 'Too many payment checks. Wait a moment; your payment is safe and will be confirmed.');
        }
        if ($path === 'checkout/verify' && $r->input('provider') === 'phonepe') {
            $v = $r->validate(['orderId' => 'required|string|max:63|regex:/^[A-Za-z0-9_-]+$/']);

            return $ok(['state' => \App\Services\PhonePe::verify($u, $v['orderId'])]);
        }
        if ($path === 'checkout/verify') {
            $v = $r->validate(['razorpay_order_id' => 'required|string|max:100', 'razorpay_payment_id' => 'required|string|max:100', 'razorpay_signature' => 'required|string|size:64']);
            Payments::verify($u, $v);

            return $ok();
        }
        if ($path === 'referrals' && $get) {
            if (! $u->referral_code) {
                $u->forceFill(['referral_code' => Referrals::makeCode((string) $u->name)])->save();
            }

            $referredUsers = User::where('referred_by', $id)
                ->select('id', 'created_at', 'email_verified_at', 'blocked')
                ->selectSub(DB::table('purchases')->selectRaw('COUNT(*)')->whereColumn('owner_id', 'users.id')->where('status', 'paid')->where('is_live', true)->whereIn('provider', ['razorpay', 'phonepe', 'cashfree'])->where('amount_paise', '>=', Referrals::config()['minQualifyingPaise'])->where('refunded_paise', 0)->whereNotNull('payment_reference')->where('plan', '!=', 'free'), 'qualifying_payments')
                ->selectSub(DB::table('referral_identities')->selectRaw('COUNT(*)')->whereColumn('owner_id', 'users.id')->where('status', 'verified'), 'verified_phone')
                ->orderByDesc('created_at')->limit(200)->get()->map(fn ($friend) => [
                    'label' => 'Friend '.substr(hash_hmac('sha256', (string) $friend->id, config('app.key')), 0, 6),
                    'joinedAt' => $friend->created_at->toIso8601String(),
                    'status' => $friend->blocked ? 'Under review' : (! $friend->email_verified_at || ! $friend->verified_phone ? 'Verification pending' : ($friend->qualifying_payments ? 'Qualifying paid referral' : 'Payment pending')),
                ]);

            return $ok(['connected' => true, 'mode' => Referrals::config()['mode'], 'wallet' => \App\Services\Wallet::summary($id), 'commissionEligible' => ! Referrals::config()['proOnly'] || (bool) (Settings::access($id)['limits']['referral'] ?? false), 'referredUsers' => $referredUsers, 'rules' => Referrals::config(), 'effectiveRateBps' => Referrals::rate($id), 'successfulBuyers' => Referrals::successfulBuyers($id), 'creator' => DB::table('creator_applications')->where('owner_id', $id)->first(), 'payoutProfile' => AffiliateProfiles::publicProfile($id), 'emailVerified' => (bool) $u->email_verified_at, 'code' => $u->referral_code, 'url' => url('/r/'.$u->referral_code), 'balance' => Referrals::balance($id), 'clicks' => DB::table('referral_clicks')->where('referrer_id', $id)->count(), 'signups' => User::where('referred_by', $id)->count(), 'commissions' => DB::table('referral_commissions')->where('referrer_id', $id)->orderByDesc('created_at')->limit(200)->get(['id', 'purchase_id', 'amount_paise', 'reversed_paise', 'rate_bps', 'available_at', 'created_at']), 'withdrawals' => DB::table('withdrawals')->where('owner_id', $id)->orderByDesc('created_at')->limit(100)->get(['id', 'amount_paise', 'method', 'destination_masked', 'status', 'reference', 'note', 'due_at', 'paid_at', 'created_at'])]);
        }
        if ($path === 'referrals/withdraw' && $r->isMethod('POST')) {
            AccountSecurity::requireRecent($r);
            $v = $r->validate(['amountPaise' => 'required|integer|min:'.max(100, (int) Referrals::config()['minimumPaise']).'|max:100000000']);

            return $ok(['id' => Referrals::request($u, $v)]);
        }
        if ($path === 'feedback' && $get) {
            $pend = \App\Services\ReviewEdits::pendingFor($id);

            return $ok(['reviews' => DB::table('feedback')->where('owner_id', $id)->orderByDesc('created_at')->limit(10)->get(['id', 'display_name', 'company', 'designation', 'rating', 'content', 'consent', 'status', 'edit_state', 'edited_at', 'created_at'])->map(fn ($f) => (array) $f + ['pendingEdit' => $pend[$f->id] ?? null])]);
        }
        // 3.56.0 Evidence check before a clean download: what this version says that the customer's own resume does not.
        if (preg_match('#^evidence/(resume|letter)/([a-f0-9-]{36})(/confirm)?$#', $path, $m)) {
            $row = DB::table($m[1] === 'resume' ? 'resume_drafts' : 'cover_letter_drafts')->where('owner_id', $id)->where('id', $m[2])->first();
            abort_unless($row, 404);
            if (! empty($m[3])) {
                abort_if($get, 405);
                \App\Services\EvidenceCheck::confirm($id, $m[1], $row);
            }

            return $ok(\App\Services\EvidenceCheck::forDocument($id, $m[1], $row) + ['revision' => (int) $row->revision]);
        }
        // 3.55.0 Ask for feedback after a resume save (V7 §28), not while editing.
        if ($path === 'feedback/ask') {
            if ($get) {
                return $ok(['ask' => \App\Services\ReviewEdits::shouldAsk($id)]);
            }
            $act = $r->input('action') === 'dismissed' ? 'feedback_prompt_dismissed' : 'feedback_prompt_shown';
            Settings::audit($id, $act);

            return $ok();
        }
        if (preg_match('#^feedback/([a-f0-9-]{36})/edits/(\d+)$#', $path, $m) && $r->isMethod('POST')) {
            \App\Services\ReviewEdits::decide($id, $m[1], (int) $m[2], $r->boolean('approve'));

            return $ok();
        }
        if ($path === 'feedback' && $r->isMethod('POST')) {
            $v = $r->validate(['displayName' => 'required|string|max:100', 'company' => 'nullable|string|max:120', 'designation' => 'nullable|string|max:120', 'rating' => 'required|integer|min:1|max:5', 'content' => 'required|string|min:10|max:2000', 'consent' => 'required|boolean']);
            abort_if(DB::table('feedback')->where('owner_id', $id)->count() >= 10, 422);
            // The same words sent twice by one account are one review.
            $norm = fn ($t) => preg_replace('/[^a-z0-9]+/', '', mb_strtolower((string) $t));
            if (DB::table('feedback')->where('owner_id', $id)->get(['content'])->contains(fn ($x) => $norm($x->content) === $norm($v['content']))) {
                throw ValidationException::withMessages(['content' => 'You have already sent this feedback. Thank you!']);
            }
            // What the writer had used, kept with the review (V7 §28): their latest paid order, else their latest saved resume.
            $usage = ($o = DB::table('purchases')->where('owner_id', $id)->whereIn('status', ['paid', 'partially_refunded', 'refunded'])->whereNotNull('purchased_at')->orderByDesc('purchased_at')->value('id')) ? 'order:'.$o
                : (($rd = DB::table('resume_drafts')->where('owner_id', $id)->orderByDesc('updated_at')->value('id')) ? 'resume:'.$rd : null);
            DB::table('feedback')->insert(['id' => (string) Str::uuid(), 'owner_id' => $id, 'display_name' => $v['displayName'], 'company' => trim((string) ($v['company'] ?? '')), 'designation' => trim((string) ($v['designation'] ?? '')), 'rating' => $v['rating'], 'content' => $v['content'], 'consent' => $v['consent'], 'consented_at' => $v['consent'] ? now() : null, 'usage_ref' => $usage, 'created_at' => now(), 'updated_at' => now()]);

            return $ok();
        }
        if (preg_match('#^feedback/([a-f0-9-]{36})/withdraw$#', $path, $m)) {
            DB::table('feedback')->where('owner_id', $id)->where('id', $m[1])->update(['consent' => false, 'status' => 'hidden', 'updated_at' => now()]);

            return $ok();
        }

        return response()->json(['ok' => false, 'error' => 'This action is not available.'], 404);
    }

    private function primaryTools(Request $r, string $docId, string $action)
    {
        $u = $r->user();
        $id = $u->id;
        $row = DB::table('resume_drafts')->where('id', $docId)->where('owner_id', $id)->first();
        abort_unless($row, 404);
        if ($action === 'primary') {
            DB::transaction(function () use ($id, $docId) {
                User::whereKey($id)->lockForUpdate()->first();
                DB::table('resume_drafts')->where('owner_id', $id)->update(['is_primary' => false]);
                DB::table('resume_drafts')->where('id', $docId)->update(['is_primary' => true, 'parent_id' => null]);
            });
            Settings::audit($id, 'primary_resume_set', $docId);

            return response()->json(['ok' => true]);
        }
        $v = $r->validate(['company' => 'required|string|max:160', 'role' => 'required|string|max:160', 'jobDescription' => 'nullable|string|max:40000', 'jobUrl' => 'nullable|url:http,https|max:1000', 'scanId' => ['nullable', 'regex:/^[a-f0-9-]{36}$/']]);
        if (! empty($v['scanId'])) {
            $sc = DB::table('ats_scans')->where('id', $v['scanId'])->where('owner_id', $id)->where('status', 'done')->first();
            abort_unless($sc, 422, 'That ATS check was not found.');
            $v['jobDescription'] = $sc->job_text;
            $v['jobUrl'] = $sc->job_url ?: null;
        }
        $new = DB::transaction(function () use ($id, $row, $v) {
            User::whereKey($id)->lockForUpdate()->first();
            abort_unless(Settings::get('features')['builder']['enabled'], 403);
            $acc = Settings::access($id);
            if (! $acc['paid']) {
                throw ValidationException::withMessages(['limit' => 'A free account keeps one resume. Choose a plan to create job-tailored versions and download.']);
            }
            if (! empty($acc['limits']['oneResume'])) {
                throw ValidationException::withMessages(['limit' => 'Quick Download covers one resume. Job Hunt adds 10 tailored resumes and 10 cover letters, one for each job.']);
            }
            if (DB::table('resume_drafts')->where('owner_id', $id)->count() >= Settings::get('features')['builder']['limit']) {
                throw ValidationException::withMessages(['limit' => 'You have reached the saved resume limit for your plan. Edit an existing resume, or choose a plan with more room.']);
            }
            $data = json_decode($row->content_json, true);
            unset($data['_profileId'], $data['_profileRevision']);
            $data['title'] = $v['role'].' · '.$v['company'];
            $data['company'] = $v['company'];
            $data['role'] = $v['role'];
            $nid = (string) Str::uuid();
            DB::table('resume_drafts')->insert(['id' => $nid, 'owner_id' => $id, 'title' => substr($data['title'], 0, 180), 'template' => $row->template, 'company' => $v['company'], 'role' => $v['role'], 'content_json' => json_encode($data), 'revision' => 1, 'is_primary' => false, 'parent_id' => $row->id, 'job_description' => $v['jobDescription'] ?? null, 'job_url' => $v['jobUrl'] ?? null, 'ats_score' => \App\Services\ResumeQuality::score($data)['score'], 'source' => 'tailored', 'created_at' => now(), 'updated_at' => now()]);
            Settings::audit($id, 'resume_variant_created', $nid);

            return $nid;
        });

        // A resume prepared for a job goes straight into the Applications tracker.
        $tracked = \App\Services\Tracker::prepared($id, $v['company'], $v['role'], (string) ($v['jobUrl'] ?? ''), $v['scanId'] ?? null, $new);

        return response()->json(['ok' => true, 'id' => $new, 'revision' => 1, 'tracker' => $tracked]);
    }

    /** Builds a resume from an uploaded file's text (already extracted in the browser) and saves it as a normal draft. */
    private function importResume(Request $r)
    {
        $v = $r->validate(['text' => 'required|string|min:60|max:120000', 'fileName' => 'nullable|string|max:200', 'template' => 'nullable|string|max:120', 'paragraphs' => 'nullable|boolean', 'replaceId' => ['nullable', 'regex:/^[a-f0-9-]{36}$/']]);
        $uid = $r->user()->id;
        $replace = ! empty($v['replaceId']) ? DB::table('resume_drafts')->where('id', $v['replaceId'])->where('owner_id', $uid)->first(['id', 'revision']) : null;
        abort_if(! empty($v['replaceId']) && ! $replace, 404);
        // No room for another resume on this plan: offer to put the upload into one the customer already has, instead of a dead end.
        $count = DB::table('resume_drafts')->where('owner_id', $uid)->count();
        $paid = Settings::access($uid)['paid'];
        if (! $replace && $count >= ($paid ? Settings::get('features')['builder']['limit'] : 1)) {
            $mine = DB::table('resume_drafts')->where('owner_id', $uid)->orderByDesc('is_primary')->orderByDesc('updated_at')->limit(20)->get(['id', 'title', 'updated_at'])->map(fn ($d) => ['id' => $d->id, 'title' => $d->title ?: 'Untitled resume', 'updatedAt' => $d->updated_at]);

            return response()->json(['ok' => false, 'needsReplace' => true, 'paid' => $paid, 'resumes' => $mine, 'error' => $paid ? 'Your plan\'s saved resumes are full. Choose a resume to replace with this file.' : 'Your free account keeps one resume. You can put this file into it, or choose a plan to keep both.'], 409);
        }
        $catalog = json_decode(file_get_contents(resource_path('data/catalog.json')), true)['templates'] ?? [];
        $lib = Settings::get('library')['templates'] ?? [];
        $ok = fn ($slug) => collect($catalog)->contains('slug', $slug) && ($lib[$slug]['published'] ?? true) !== false;
        // An uploaded resume starts in a plain, ATS-conscious layout (no photo, one column); the customer can change it in the builder.
        $slug = ! empty($v['template']) && $ok($v['template']) ? $v['template'] : (collect($catalog)->first(fn ($t) => $ok($t['slug']) && ! empty($t['ats']) && empty($t['photo']) && empty($t['creative']))['slug'] ?? collect($catalog)->first(fn ($t) => $ok($t['slug']))['slug'] ?? null);
        abort_unless($slug, 422, 'No resume template is available right now.');
        $parsed = \App\Services\ResumeImport::parse($v['text'], $slug, (string) ($v['fileName'] ?? ''), (bool) ($v['paragraphs'] ?? false));
        $data = $parsed['data'];
        if (trim($data['personal']['name']) === '') {
            $data['personal']['name'] = 'Your name';
        }
        $r->merge(['id' => $replace?->id, 'revision' => $replace?->revision, 'data' => $data]);
        $saved = $this->documents($r, 'resumes', $replace?->id)->getData(true);
        DB::table('resume_drafts')->where('id', $saved['id'])->where('owner_id', $r->user()->id)->update(['source' => 'import', 'content_json' => DB::raw("REPLACE(content_json, '\"sectionLabels\":[]', '\"sectionLabels\":{}')")]);
        $q = \App\Services\ResumeQuality::score($data);

        return response()->json(['ok' => true, 'id' => $saved['id'], 'revision' => $saved['revision'], 'found' => $parsed['found'], 'warnings' => $parsed['warnings'], 'quality' => ['score' => $q['score'], 'tips' => $q['tips']]]);
    }

    private function accountExport(User $u): array
    {
        $id = $u->id;
        $rows = fn ($t, $cols = ['*']) => DB::table($t)->where('owner_id', $id)->get($cols)->map(fn ($x) => (array) $x)->all();
        $decode = fn (array $list) => array_map(function ($x) {
            $x['content'] = json_decode($x['content_json'] ?? 'null', true);
            unset($x['content_json']);

            return $x;
        }, $list);

        return ['generatedAt' => now()->toIso8601String(), 'account' => ['name' => $u->name, 'email' => $u->email, 'createdAt' => $u->created_at, 'referralCode' => $u->referral_code], 'profile' => (array) DB::table('profiles')->where('owner_id', $id)->first(), 'resumes' => $decode($rows('resume_drafts')), 'coverLetters' => $decode($rows('cover_letter_drafts')), 'applications' => $rows('applications'), 'taraChats' => DB::table('tara_messages')->where('owner_id', $id)->where('content', '!=', '')->orderBy('created_at')->get(['conversation_id', 'role', 'content', 'created_at'])->map(fn ($x) => (array) $x)->all(), 'purchases' => $rows('purchases', ['id', 'plan', 'amount_paise', 'refunded_paise', 'currency', 'status', 'coupon_code', 'purchased_at', 'access_until']), 'reviews' => $rows('feedback', ['display_name', 'rating', 'content', 'status', 'created_at']), 'referralCommissions' => DB::table('referral_commissions')->where('referrer_id', $id)->get(['amount_paise', 'rate_bps', 'created_at'])->map(fn ($x) => (array) $x)->all(), 'withdrawals' => $rows('withdrawals', ['amount_paise', 'destination_masked', 'status', 'reference', 'created_at']), 'payoutProfile' => (array) DB::table('payout_profiles')->where('owner_id', $id)->first(['status', 'destination_masked']), 'creatorApplication' => (array) DB::table('creator_applications')->where('owner_id', $id)->first(['status', 'audience', 'rate_bps', 'created_at']), 'refundRequests' => $rows('refund_requests', ['purchase_id', 'status', 'amount_paise', 'reason', 'note', 'created_at']), 'walletTransactions' => $rows('wallet_transactions', ['kind', 'amount_paise', 'note', 'earned_at', 'expires_at', 'created_at']), 'serviceOrders' => $rows('service_orders', ['service', 'status', 'note', 'created_at', 'delivered_at']), 'atsChecks' => $rows('ats_scans', ['id', 'source', 'job_url', 'job_title', 'company', 'score', 'result_json', 'status', 'created_at']), 'activity' => DB::table('activity_events')->where('owner_id', $id)->orderByDesc('created_at')->limit(500)->get(['event', 'reference', 'created_at'])->map(fn ($x) => (array) $x)->all(),
            'supportRequests' => \App\Services\SupportCentre::mine($u),
            'resumeAndLetterRequests' => \Illuminate\Support\Facades\Schema::hasTable('service_requests') ? DB::table('service_requests')->where('owner_id', $id)->get(['id', 'status', 'scan_id', 'output_json', 'created_at'])->map(fn ($x) => ['output' => json_decode((string) $x->output_json, true)] + array_diff_key((array) $x, ['output_json' => 1]))->all() : []];
    }

    // The account and everything in it is removed for good. Money records stay for accounting, detached from the person (AccountEraser).
    public function deleteAccount(User $u): void
    {
        abort_if($u->is_admin, 422, 'The owner account cannot be deleted here.');
        abort_if(DB::table('withdrawals')->where('owner_id', $u->id)->whereIn('status', ['requested', 'processing'])->exists(), 422, 'Finish or cancel your open withdrawal first.');
        \App\Services\AccountEraser::erase($u->id);
    }

    /**
     * Why two checks can give the same score: this resume has exactly the same text as another resume already checked
     * against this job, or it is a tailored copy that has not been changed since it was copied.
     */
    private function sameContent(string $owner, object $resume, string $hash, string $jobText, string $scanId): ?array
    {
        if (! empty($resume->parent_id)) {
            $parent = DB::table('resume_drafts')->where('id', $resume->parent_id)->where('owner_id', $owner)->first(['title', 'content_json']);
            if ($parent && \App\Services\AtsEngine::fingerprint(json_decode((string) $parent->content_json, true) ?: []) === $hash) {
                return ['kind' => 'unchanged_copy', 'title' => $parent->title];
            }
        }
        $earlier = DB::table('ats_scans')->where('ats_scans.owner_id', $owner)->where('ats_scans.status', 'done')->where('ats_scans.id', '!=', $scanId)->where('ats_scans.resume_id', '!=', $resume->id)
            ->where('ats_scans.job_text', $jobText)->join('resume_drafts', 'resume_drafts.id', '=', 'ats_scans.resume_id')->orderByDesc('ats_scans.created_at')->limit(10)->get(['ats_scans.result_json', 'resume_drafts.title', 'resume_drafts.content_json']);
        foreach ($earlier as $e) {
            if (\App\Services\AtsEngine::fingerprint(json_decode((string) $e->content_json, true) ?: []) === $hash) {
                return ['kind' => 'same_text', 'title' => $e->title];
            }
        }

        return null;
    }

    /** Tara chat for the signed-in customer: status, send a message, past conversations, rate an answer, delete a conversation. */
    private function tara(Request $r, string $path)
    {
        $u = $r->user();
        $ok = fn ($a = []) => response()->json(['ok' => true, ...$a]);
        if ($path === 'status' && $r->isMethod('GET')) {
            return $ok(['tara' => \App\Services\TaraChat::status($u)]);
        }
        if ($path === 'nudge' && $r->isMethod('GET')) {
            return $ok(['nudge' => \App\Services\TaraChat::nudge($u)]);
        }
        if ($path === 'message' && $r->isMethod('POST')) {
            $v = $r->validate(['conversationId' => ['nullable', 'regex:/^[a-f0-9-]{36}$/'], 'text' => 'required|string|max:6000']);
            \App\Services\EmailVerification::guard($u);

            return $ok(\App\Services\TaraChat::send($u, $v['conversationId'] ?? null, $v['text']));
        }
        if ($path === 'conversations' && $r->isMethod('GET')) {
            return $ok(['conversations' => DB::table('tara_conversations')->where('owner_id', $u->id)->where('mode', 'customer')->where('status', '!=', 'deleted')->orderByDesc('last_at')->limit(30)->get(['id', 'title', 'messages', 'last_at'])]);
        }
        if (preg_match('#^conversations/([a-f0-9-]{36})$#', $path, $m) && $r->isMethod('GET')) {
            $c = DB::table('tara_conversations')->where('id', $m[1])->where('owner_id', $u->id)->where('mode', 'customer')->where('status', '!=', 'deleted')->first(['id', 'title']);
            abort_unless($c, 404);
            $msgs = DB::table('tara_messages')->where('conversation_id', $c->id)->where('owner_id', $u->id)->orderBy('created_at')->limit(200)->get(['id', 'role', 'content', 'meta_json', 'rating', 'created_at']);

            return $ok(['conversation' => $c, 'messages' => $msgs->map(fn ($x) => ['id' => $x->id, 'role' => $x->role, 'content' => $x->content, 'links' => json_decode((string) $x->meta_json, true)['links'] ?? [], 'rating' => $x->rating, 'at' => $x->created_at])]);
        }
        if (preg_match('#^conversations/([a-f0-9-]{36})/delete$#', $path, $m) && $r->isMethod('POST')) {
            $n = DB::table('tara_conversations')->where('id', $m[1])->where('owner_id', $u->id)->where('mode', 'customer')->update(['status' => 'deleted', 'title' => '', 'summary' => null, 'updated_at' => now()]);
            abort_unless($n, 404);
            DB::table('tara_messages')->where('conversation_id', $m[1])->where('owner_id', $u->id)->where('mode', 'customer')->update(['content' => '', 'meta_json' => null]); // the words are wiped; counts stay for usage limits

            return $ok();
        }
        if ($path === 'event' && $r->isMethod('POST')) {
            $v = $r->validate(['kind' => 'required|in:offer_clicked', 'plan' => ['nullable', 'string', 'max:60', 'regex:/^[a-z0-9_-]*$/'], 'source' => 'required|in:dashboard,chat']);
            abort_if(\Illuminate\Support\Facades\RateLimiter::tooManyAttempts('tara-event:'.$u->id, 20), 429);
            \Illuminate\Support\Facades\RateLimiter::hit('tara-event:'.$u->id, 3600);
            \App\Services\TaraGuard::offer($u->id, $v['kind'], $v['plan'] ?? null, $v['source']);

            return $ok();
        }
        if ($path === 'rate' && $r->isMethod('POST')) {
            $v = $r->validate(['messageId' => ['required', 'regex:/^[a-f0-9-]{36}$/'], 'rating' => 'required|in:1,-1']);
            abort_unless(DB::table('tara_messages')->where('id', $v['messageId'])->where('owner_id', $u->id)->where('mode', 'customer')->where('role', 'assistant')->update(['rating' => (int) $v['rating']]), 404);

            return $ok();
        }
        abort(404);
    }

    private function documents(Request $r, string $type, ?string $doc)
    {
        $u = $r->user();
        $id = $u->id;
        $table = $type === 'resumes' ? 'resume_drafts' : 'cover_letter_drafts';
        $one = $type === 'resumes' ? 'resume' : 'letter';
        $acc = Settings::access($id)['limits'];
        $limit = $type === 'resumes' ? (int) Settings::get('features')['builder']['limit'] : (int) (Settings::get('features')['letter']['draftLimit'] ?? 500);
        $query = DB::table($table)->where('owner_id', $id);
        if ($r->isMethod('GET')) {
            if ($doc) {
                $row = (clone $query)->where('id', $doc)->first();
                abort_unless($row, 404);

                return response()->json(['ok' => true, $one => ['id' => $row->id, 'revision' => $row->revision, 'isPrimary' => (bool) ($row->is_primary ?? false), 'parentId' => $row->parent_id ?? null, 'jobDescription' => $row->job_description ?? '', 'jobUrl' => $row->job_url ?? '', 'data' => json_decode($row->content_json, true)]]);
            }

            $rows = $query->orderByDesc('updated_at')->get($type === 'resumes' ? ['id', 'title', 'template', 'company', 'role', 'revision', 'is_primary', 'parent_id', 'ats_score', 'downloaded_at', 'source', 'created_at', 'updated_at'] : ['id', 'title', 'template', 'company', 'role', 'revision', 'downloaded_at', 'created_at', 'updated_at']);
            if ($type === 'resumes') {
                // Resumes saved before the score existed are scored the first time they are listed.
                foreach ($rows->filter(fn ($x) => $x->ats_score === null)->take(40) as $x) {
                    $c = DB::table('resume_drafts')->where('id', $x->id)->value('content_json');
                    $x->ats_score = \App\Services\ResumeQuality::score(json_decode((string) $c, true) ?: [])['score'];
                    DB::table('resume_drafts')->where('id', $x->id)->update(['ats_score' => $x->ats_score]);
                }
                // Best job match each resume has reached, and the latest one.
                $scans = DB::table('ats_scans')->where('owner_id', $id)->where('status', 'done')->whereNotNull('score')->whereIn('resume_id', $rows->pluck('id'))->orderByDesc('created_at')->get(['resume_id', 'score', 'job_title', 'company', 'created_at'])->groupBy('resume_id');
                $order = $rows->sortBy('created_at')->pluck('id')->values()->all();
                $rows = $rows->map(function ($x) use ($scans, $order) {
                    $x = (array) $x;
                    $s = $scans[$x['id']] ?? collect();
                    $last = $s->first();
                    $x['match'] = $last ? ['score' => (int) $last->score, 'company' => $last->company, 'role' => $last->job_title, 'best' => (int) $s->max('score'), 'count' => $s->count()] : null;
                    $x['locked'] = true;
                    $x['number'] = array_search($x['id'], $order, true) + 1;

                    return $x;
                })->values();
            }

            return response()->json(['ok' => true, $type => $rows, 'limit' => $limit, 'canDelete' => $type !== 'resumes' || (bool) (Settings::get('features')['builder']['allowDelete'] ?? false), 'credits' => Credits::status($id)]);
        }
        if ($r->isMethod('DELETE')) {
            $existing = $doc ? (clone $query)->where('id', $doc)->first() : null;
            abort_unless($existing, 404);
            if ($type === 'resumes' && ! (Settings::get('features')['builder']['allowDelete'] ?? false)) {
                abort(422, 'Saved resumes stay in your account so your download credits stay accurate. Edit this resume instead, or contact support if you need it removed.');
            }
            abort_if(! empty($existing->downloaded_at), 422, 'This '.$one.' has been downloaded, so it stays in your account. You can still edit it.');
            abort_unless((clone $query)->where('id', $doc)->delete(), 404);
            if ($type === 'resumes' && ! DB::table('resume_drafts')->where('owner_id', $id)->where('is_primary', true)->exists()) {
                $next = DB::table('resume_drafts')->where('owner_id', $id)->orderBy('created_at')->value('id');
                if ($next) {
                    DB::table('resume_drafts')->where('id', $next)->update(['is_primary' => true, 'parent_id' => null]);
                }
            }
            Settings::audit($id, $one.'_deleted', $doc);

            return response()->json(['ok' => true]);
        }
        $r->validate(['data' => 'required|array', 'data.version' => 'required|in:1', 'data.title' => 'required|string|max:180', 'data.template' => 'required|string|max:120', 'data.personal' => 'required|array', 'data.personal.name' => 'required|string|max:300', 'data.accent' => 'required|regex:/^#[0-9a-fA-F]{6}$/', 'data.font' => 'required|in:Arial,Georgia,Verdana', 'id' => 'nullable|uuid', 'revision' => 'nullable|integer']);
        $rules = ['data.personal.*' => 'nullable|string|max:1000', 'data.hidden' => 'sometimes|array|max:12', 'data.hidden.*' => 'string|max:30', 'data.order.*' => 'string|in:summary,experience,education,projects,skills,certifications,languages,awards', 'data.sectionLabels' => 'sometimes|array|max:12', 'data.sectionLabels.*' => 'nullable|string|max:80', 'data.documentLanguage' => 'sometimes|in:en'];
        foreach (['summary', 'skills', 'languages', 'awards', 'opening', 'evidence', 'motivation', 'closing', 'date', 'recipient', 'subject', 'salutation', 'signoff'] as $field) {
            $rules['data.'.$field] = 'sometimes|nullable|string|max:12000';
        }foreach (['experience', 'education', 'projects', 'certifications'] as $section) {
            $rules['data.'.$section.'.*'] = 'array';
            foreach (['role', 'degree', 'name', 'company', 'school', 'issuer', 'city', 'tools', 'link', 'start', 'end', 'date', 'bullets', 'details', 'id'] as $field) {
                $rules['data.'.$section.'.*.'.$field] = 'sometimes|nullable|string|max:12000';
            }$rules['data.'.$section.'.*.current'] = 'sometimes|boolean';
        }$r->validate($rules);
        $data = $r->input('data');
        abort_if(strlen(json_encode($data)) > 450000, 413);
        if ($type === 'resumes') {
            $r->validate(['data.order' => 'required|array|max:12', 'data.experience' => 'present|array|max:50', 'data.education' => 'present|array|max:50', 'data.projects' => 'present|array|max:50', 'data.certifications' => 'present|array|max:50', 'data.photo' => 'nullable|string|max:200000']);
            if (! empty($data['photo'])) {
                abort_unless(preg_match('#^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$#', $data['photo']), 422);
                $bytes = base64_decode(explode(',', $data['photo'], 2)[1], true);
                $im = $bytes ? @getimagesizefromstring($bytes) : false;
                abort_unless($im && $im[0] <= 1024 && $im[1] <= 1024, 422);
            }
        } else {
            $r->validate(['data.company' => 'required|string|max:160', 'data.role' => 'required|string|max:160', 'data.opening' => 'required|string|max:8000', 'data.evidence' => 'required|string|max:12000']);
        }
        unset($data['_profileId'],$data['_profileRevision']);
        $result = DB::transaction(function () use ($r, $table, $id, $data, $limit, $one, $type) {
            User::whereKey($id)->lockForUpdate()->first();
            abort_unless(Settings::get('features')[$type === 'resumes' ? 'builder' : 'letter']['enabled'], 403);
            $slug = $data['template'];
            $already = $r->input('id') && DB::table($table)->where('id', $r->input('id'))->where('owner_id', $id)->where('template', $slug)->exists();
            abort_if(! $already && (Settings::get('library')[$type === 'resumes' ? 'templates' : 'letters'][$slug]['published'] ?? true) === false, 422, 'This template is no longer available. Choose another template.');
            abort_unless(\App\Services\TemplateLibrary::exists($type === 'resumes' ? 'resume' : 'letter', (string) $slug), 422);
            $record = ['title' => $data['title'], 'template' => $slug, 'content_json' => json_encode($data), 'company' => $data['company'] ?? '', 'role' => $data['role'] ?? '', 'updated_at' => now()];
            if ($type === 'resumes') {
                $record['ats_score'] = \App\Services\ResumeQuality::score($data)['score'];
            }
            // 3.52.0 cover letters remember the resume, ATS check and application they were made from (only the customer's own).
            $src = (array) $r->input('source', []);
            if ($type === 'letters' && \Illuminate\Support\Facades\Schema::hasColumn('cover_letter_drafts', 'source_resume_id')) {
                foreach (['resumeId' => ['source_resume_id', 'resume_drafts'], 'scanId' => ['source_scan_id', 'ats_scans'], 'applicationId' => ['source_application_id', 'applications']] as $k => [$col, $tbl]) {
                    $val = (string) ($src[$k] ?? '');
                    if (preg_match('/^[a-f0-9-]{36}$/', $val) && DB::table($tbl)->where('id', $val)->where('owner_id', $id)->exists()) {
                        $record[$col] = $val;
                    }
                }
            }
            if ($r->input('id')) {
                $did = $r->input('id');
                $rev = (int) $r->input('revision');
                if ($type === 'resumes') {
                    \App\Services\ResumeVersions::beforeSave($id, $did); // 3.52.0: the previous content is kept as a version
                }
                abort_unless(DB::table($table)->where('id', $did)->where('owner_id', $id)->where('revision', $rev)->update([...$record, 'revision' => $rev + 1]), 409);
                $rev++;
            } else {
                if (! Settings::access($id)['paid'] && DB::table($table)->where('owner_id', $id)->count() >= 1) {
                    throw ValidationException::withMessages(['limit' => 'A free account keeps one '.($type === 'resumes' ? 'resume' : 'cover letter').'. Choose a plan to create more and to download.']);
                }
                if (DB::table($table)->where('owner_id', $id)->count() >= $limit) {
                    throw ValidationException::withMessages(['limit' => 'You have reached the saved '.($type === 'resumes' ? 'resume' : 'cover letter').' limit for your plan. Open an existing one to edit it, or choose a plan with more room.']);
                }$did = (string) Str::uuid();
                $rev = 1;
                DB::table($table)->insert([...$record, 'id' => $did, 'owner_id' => $id, 'revision' => 1, 'created_at' => now(), ...($type === 'resumes' ? ['is_primary' => ! DB::table('resume_drafts')->where('owner_id', $id)->exists()] : [])]);
            }Settings::audit($id, $one.'_saved', $did);

            return ['id' => $did, 'revision' => $rev, ...($type === 'resumes' ? ['ats' => ['score' => $record['ats_score'], 'tips' => array_slice(\App\Services\ResumeQuality::score($data)['tips'], 0, 3)]] : [])];
        });
        if ($type === 'resumes') {
            MailAutomation::queue($u, 'resume_saved', 'w'.(int) floor(time() / (14 * 86400)));
        }

        return response()->json(['ok' => true, ...$result]);
    }
}

CVTara update 3.14.1. Extract over the site folder, then clear and rebuild pages in Speed & traffic.

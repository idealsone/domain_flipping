CVTara update 3.14.0. Extract over the site folder (cvtara_app/ and public_html/), then clear and rebuild pages in Speed & traffic.

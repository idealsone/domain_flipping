CVTara update 3.13.0 (includes everything since 3.12.0)

1. Upload this zip to the folder that holds public_html (domains/cvtara.com) and extract it there, replacing files.
   Files under cvtara_app/ go to the private app folder, files under public_html/ go to the website folder.
2. Run the database update once (installer page, or: php artisan migrate --force). It marks existing customers as email-confirmed.
3. In the owner console open Speed & traffic: "Clear ready-made pages", then "Rebuild all pages now". Hard-refresh the browser.
4. Put the real mailbox password in cvtara_app/.env (MAIL_PASSWORD) so email can be sent.
5. Delete this zip from public_html after use.
